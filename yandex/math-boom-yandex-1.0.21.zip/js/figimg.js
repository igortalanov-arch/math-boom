/* v1.0.15 figure art lives in assets/figures (webp + png fallback), no base64 in HTML */
window.FIGN=10;
function fp(i){return (i<10?'0':'')+i;}
window.FIGTHUMB=function(i){return 'assets/figures/thumb/'+fp(i)+'.webp';};
window.FIGCARD=function(i){return 'assets/figures/card/'+fp(i)+'.webp';};
window.FIGHERO=function(i){return 'assets/figures/hero/'+fp(i)+'.webp';};
window.FIGIMG=[];for(let i=0;i<10;i++)FIGIMG[i]=FIGTHUMB(i);
window.figErr=function(el){if(!el||el.dataset.fb)return;el.dataset.fb='1';el.src=el.src.replace('.webp','.png');};
