'use strict';
const $=id=>document.getElementById(id);
/* ================= 2D particle overlay ================= */
const fx=document.createElement('canvas');fx.id='fx';document.body.appendChild(fx);const fctx=fx.getContext('2d');let P=[];
function fxResize(){fx.width=innerWidth;fx.height=innerHeight}addEventListener('resize',fxResize);fxResize();
const COLORS=['#ff5a5a','#4aa3ff','#3ddc7a','#ffd44d'];
function burst(x,y,c,n,spd){ for(let i=0;i<(n||14);i++){const a=Math.random()*6.28,v=(spd||3)*(.4+Math.random());
  P.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-1,l:1,s:2+Math.random()*3,c,t:'spark'});}
  const r=document.createElement('div');r.className='ring';r.style.left=x+'px';r.style.top=y+'px';
  r.style.borderColor=c;document.body.appendChild(r);setTimeout(()=>r.remove(),600); }
function confetti(n){ for(let i=0;i<n;i++)P.push({x:Math.random()*fx.width,y:-20-Math.random()*200,
  vx:(Math.random()-.5)*2,vy:2+Math.random()*3,l:1.6,s:4+Math.random()*5,
  c:['#ff5a5a','#4aa3ff','#3ddc7a','#ffd44d','#e8c56a','#fff'][i%6],t:'conf',r:Math.random()*6.28,vr:(Math.random()-.5)*.3}); }
function firework(){ const x=fx.width*(.2+Math.random()*.6),y=fx.height*(.15+Math.random()*.3),
  c=['#e8c56a','#c0c8e0','#3ddc84'][Math.random()*3|0]; burst(x,y,c,26,5); noise(.25,.15,1200); }
function ftext(x,y,txt,big){ const d=document.createElement('div');d.className='ftext'+(big?' big':'');
  d.textContent=txt;d.style.left=x+'px';d.style.top=y+'px';document.body.appendChild(d);setTimeout(()=>d.remove(),1000); }
setInterval(()=>{ if(P.length<400)P.push({x:innerWidth/2+(Math.random()-.5)*280,y:innerHeight/2+(Math.random()-.5)*320,
  vx:0,vy:-.3,l:.8,s:1.5,c:'#ffe9a3',t:'spark'}); },300);
/* ================= game data (TZ §5) ================= */
const OPS=['+','−','×','÷'],MOVES=[30,28,26,24],POOLMAX=[5,5,7,9,9];
const LC=[
 {c:64,d:12,g:4,S:220,H:356,t:14},
 {c:50,d:10,g:3,S:176,H:282,t:12.5},
 {c:38,d:8,g:2.5,S:139,H:220,t:10.5},
 {c:28,d:6,g:2,S:108,H:168,t:10}
].map(o=>({...o,p:10,Rf:o.S/2,fw:(3*o.c+2*o.g)/2,fh:(5*o.c+4*o.g)/2}));
const TSCALE=[1,1.25,1.5,1.8];
const PIP={1:[4],2:[0,8],3:[0,4,8],4:[0,2,6,8],5:[0,2,4,6,8],6:[0,2,3,5,6,8],7:[0,2,3,4,5,6,8],8:[0,1,2,3,5,6,7,8],9:[0,1,2,3,4,5,6,7,8]};
const PIPMASK=[0,0,0,0,0,0,0,0,0,0];for(let n=1;n<10;n++)PIP[n].forEach(i=>PIPMASK[n]|=1<<i);
let shells=[],cur=0,selected=[],locked=false,score=0,moves=30,combo=0,mult=1,t0=0,curOp='+',finaleOn=false;
let colIdx=0,curOps=OPS.slice(),MBactive=false,runTime=0;
let formulaLock=0,autoOn=false;
function rnd(n){return Math.random()*n|0}
function pick(a){return a[rnd(a.length)]}
function relFor(op){return (op==='+'||op==='−')
 ? v=>v[0]===v[1]+v[2]||v[1]===v[0]+v[2]||v[2]===v[0]+v[1]
 : v=>v[0]===v[1]*v[2]||v[1]===v[0]*v[2]||v[2]===v[0]*v[1];}
function shellEqOk(tr,op){
 const v=tr.map(s=>s.n);
 for(let p=0;p<3;p++){const r=v[p],x=v[(p+1)%3],y=v[(p+2)%3];
  if(op==='+'){if(x+y===r)return true;}
  else if(op==='−'){if(x-y===r||y-x===r)return true;}
  else if(op==='×'){if(x*y===r)return true;}
  else{if((y>0&&x%y===0&&x/y===r)||(x>0&&y%x===0&&y/x===r))return true;}}
 return false;}
function validateShell(eqs,op){
 if(!eqs||!eqs.length)return false;
 if(!eqs.every(tr=>shellEqOk(tr,op)))return false;
 const cnt={};eqs.forEach(tr=>tr.forEach(s=>{const k=s.n+'_'+s.col;cnt[k]=(cnt[k]||0)+1;}));
 return Object.values(cnt).some(n=>n>=3);}
function genShell(op){
 const rel=relFor(op),fam=(op==='+'||op==='−')?'sum':'prod';
 for(let attempt=0;attempt<40;attempt++){
  const ADJ=[[1,3,4,5],[0,2,4,5],[1,3,4,5],[0,2,4,5],[0,1,2,3],[0,1,2,3]];
  const slots=[],free=[[],[],[],[],[],[]];
  for(let f=0;f<6;f++){const rows=f<4?5:3;for(let r=0;r<rows;r++)for(let c=0;c<3;c++){const s={f,r,c};slots.push(s);free[f].push(s);}}
  let ok=true;const placed=[];let guard=0;
  while(free.some(fc=>fc.length)&&guard++<600){
   const faces=[0,1,2,3,4,5].filter(f=>free[f].length);
   const f=faces[rnd(faces.length)];
   const a=pick(free[f]);let b=null,c=null;
   const same=free[f].filter(x=>x!==a);
   if(same.length>=2&&Math.random()<.6){b=pick(same);c=pick(same.filter(x=>x!==b));}
   if(!b){const adj=ADJ[f].filter(g=>free[g].length);
    if(same.length&&adj.length){b=pick(same);c=pick(free[pick(adj)]);}}
   if(!b){const adj=ADJ[f].filter(g=>free[g].length);
    if(adj.length>=2){const g=pick(adj),h=pick(adj.filter(x=>x!==g));
     if(h!==undefined){b=pick(free[g]);c=pick(free[h]);}}}
   if(!b||!c)continue;
   placed.push([a,b,c]);
   [a,b,c].forEach(s=>free[s.f]=free[s.f].filter(x=>x!==s));
  }
  if(free.some(fc=>fc.length))ok=false;
  if(!ok)continue;
  let numsOk=true;
  placed.forEach(tr=>{ let done=false;
   for(let t=0;t<250&&!done;t++){
    const ri=rnd(3),qi=(ri+1)%3,ui=(ri+2)%3;
    if(fam==='sum'){const a=1+rnd(POOLMAX[tr[qi].r]),b=1+rnd(POOLMAX[tr[ui].r]),c=a+b;
     if(c<=POOLMAX[tr[ri].r]){tr[ri].n=c;tr[qi].n=a;tr[ui].n=b;done=true;}}
    else{const a=2+rnd(Math.max(1,POOLMAX[tr[qi].r]-1)),b=2+rnd(Math.max(1,POOLMAX[tr[ui].r]-1)),c=a*b;
     if(c<=POOLMAX[tr[ri].r]){tr[ri].n=c;tr[qi].n=a;tr[ui].n=b;done=true;}}}
   if(!done)numsOk=false;});
  if(!numsOk)continue;
  placed.forEach(tr=>tr.forEach(s=>{s.col=rnd(4)}));
  let tripleOk=false;
  for(let tt=0;tt<40&&!tripleOk;tt++){
   const Tv=fam==='sum'?6+rnd(4):4+rnd(6),Tc=rnd(4);const cands=[];
   placed.forEach((tr,eqId)=>{ for(let i=0;i<3;i++){
     const s=tr[i];if(POOLMAX[s.r]<Tv)continue;
     const o0=tr[(i+1)%3],o1=tr[(i+2)%3];let got=false;
     for(let x=1;x<=POOLMAX[o0.r]&&!got;x++)for(let y=1;y<=POOLMAX[o1.r]&&!got;y++){
      const good=fam==='sum'?(x+y===Tv):(x*y===Tv);
      if(good){cands.push({eqId,s,apply:()=>{s.n=Tv;o0.n=x;o1.n=y;s.col=Tc;s.tri=1;}});got=true;}}}});
   const seen=new Set(),chosen=[];
   for(const cd of cands.sort(()=>Math.random()-.5)){ if(!seen.has(cd.eqId)){seen.add(cd.eqId);chosen.push(cd);if(chosen.length===3)break;} }
   if(chosen.length===3){chosen.forEach(cd=>cd.apply());tripleOk=true;}}
  const cnt={};placed.forEach(tr=>tr.forEach(s=>{(cnt[s.n+'_'+s.col]=cnt[s.n+'_'+s.col]||[]).push(s)}));
  for(const k in cnt){ if(cnt[k].length>=3)cnt[k].slice(3).forEach(s=>{ if(!s.tri)s.col=(s.col+1+rnd(3))%4;}); }
  if(!validateShell(placed,op))continue;
  return {slots,eqs:placed,removed:0,rowDone:[]};
 } return null;
}
/* slot -> column-space position (faces 0-3 sides, 4 top, 5 bottom) */
function slotGeom(L,s){const e=L.c+L.g;let x,y,z;
 if(s.f<4){x=(s.c-1)*e;y=(2-s.r)*e;z=L.Rf+1.5-L.d/2;
  const a=s.f*Math.PI/2,ca=Math.cos(a),sa=Math.sin(a);
  return [x*ca+z*sa,y,-x*sa+z*ca];}
 x=(s.c-1)*e;z=(s.r-1)*e;const yy=L.H/2+1.5-L.d/2;
 return [x,s.f===4?yy:-yy,z];}
/* build per-cube render data (column space) */
function buildCubeData(){
 cubes=[];
 shells.forEach((sh,li)=>{ const L=LC[li];
  sh.slots.forEach((s,idx)=>{
   s.cube={li,idx, pos:slotGeom(L,s), rot:s.f, s:L.c, d:L.d,
     n:s.n, col:s.col, slot:s, anim:null, hidden:false};
   cubes.push(s.cube);
  });
 });
}
let cubes=[];
/* ================= minimal mat4 ================= */
function mI(){return new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1])}
function mMul(a,b){const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++){let s=0;
 for(let k=0;k<4;k++)s+=a[k*4+r]*b[c*4+k];o[c*4+r]=s;}return o;}
function mPersp(fov,asp,n,f){const t=1/Math.tan(fov/2);return new Float32Array([t/asp,0,0,0,0,t,0,0,0,0,(f+n)/(n-f),-1,0,0,2*f*n/(n-f),0])}
function mRotX(a){const c=Math.cos(a),s=Math.sin(a);return new Float32Array([1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1])}
function mRotY(a){const c=Math.cos(a),s=Math.sin(a);return new Float32Array([c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1])}
function mScale(s){return new Float32Array([s,0,0,0,0,s,0,0,0,0,s,0,0,0,0,1])}
function mTrans(x,y,z){const m=mI();m[12]=x;m[13]=y;m[14]=z;return m}
function mInv(m){const o=new Float32Array(16);
 const a00=m[0],a01=m[1],a02=m[2],a03=m[3],a10=m[4],a11=m[5],a12=m[6],a13=m[7],
 a20=m[8],a21=m[9],a22=m[10],a23=m[11],a30=m[12],a31=m[13],a32=m[14],a33=m[15];
 const b00=a00*a11-a01*a10,b01=a00*a12-a02*a10,b02=a00*a13-a03*a10,b03=a01*a12-a02*a11,
 b04=a01*a13-a03*a11,b05=a02*a13-a03*a12,b06=a20*a31-a21*a30,b07=a20*a32-a22*a30,
 b08=a20*a33-a23*a30,b09=a21*a32-a22*a31,b10=a21*a33-a23*a31,b11=a22*a33-a23*a32;
 let det=b00*b11-b01*b10+b02*b09+b03*b08-b04*b07+b05*b06;if(!det)return o;det=1/det;
 o[0]=(a11*b11-a12*b10+a13*b09)*det;o[1]=(a02*b10-a01*b11-a03*b09)*det;o[2]=(a31*b05-a32*b04+a33*b03)*det;o[3]=(a22*b04-a21*b05-a23*b03)*det;
 o[4]=(a12*b08-a10*b11-a13*b07)*det;o[5]=(a00*b11-a02*b08+a03*b07)*det;o[6]=(a32*b02-a30*b05-a33*b01)*det;o[7]=(a20*b05-a22*b02+a23*b01)*det;
 o[8]=(a10*b10-a11*b08+a13*b06)*det;o[9]=(a01*b08-a00*b10-a03*b06)*det;o[10]=(a30*b04-a31*b02+a33*b00)*det;o[11]=(a21*b02-a20*b04-a23*b00)*det;
 o[12]=(a11*b07-a10*b09-a12*b06)*det;o[13]=(a00*b09-a01*b07+a02*b06)*det;o[14]=(a31*b01-a30*b03-a32*b00)*det;o[15]=(a20*b03-a21*b01+a22*b00)*det;
 return o;}
function tP(m,v){const w=m[3]*v[0]+m[7]*v[1]+m[11]*v[2]+m[15];
 return [(m[0]*v[0]+m[4]*v[1]+m[8]*v[2]+m[12])/w,(m[1]*v[0]+m[5]*v[1]+m[9]*v[2]+m[13])/w,(m[2]*v[0]+m[6]*v[1]+m[10]*v[2]+m[14])/w];}
function tD(m,v){return [m[0]*v[0]+m[4]*v[1]+m[8]*v[2],m[1]*v[0]+m[5]*v[1]+m[9]*v[2],m[2]*v[0]+m[6]*v[1]+m[10]*v[2]];}
/* ================= WebGL ================= */
const cv=$('gl');
const gl=cv.getContext('webgl2',{alpha:true,antialias:true})||cv.getContext('webgl',{alpha:true,antialias:true});
const isGL2=!!(window.WebGL2RenderingContext&&gl instanceof WebGL2RenderingContext);
const extI=isGL2?null:(gl.getExtension('ANGLE_instanced_arrays'));
function vDivisor(i,d){isGL2?gl.vertexAttribDivisor(i,d):extI.vertexAttribDivisorANGLE(i,d)}
function drawInst(n,c){isGL2?gl.drawElementsInstanced(gl.TRIANGLES,n,gl.UNSIGNED_SHORT,0,c):extI.drawElementsInstancedANGLE(gl.TRIANGLES,n,gl.UNSIGNED_SHORT,0,c)}
const VS=`
attribute vec3 aPos;attribute vec3 aNrm;attribute vec2 aUV;attribute float aFace;
attribute vec3 iPos;attribute vec3 iScale;attribute float iRot;attribute float iColor;attribute float iMask;attribute vec3 iExtra;
uniform mat4 uMVP;uniform mat3 uNM;
varying vec3 vN;varying vec2 vUV;varying float vFace;varying float vColor;varying float vState;varying float vNum;varying float vMask;
void main(){
 mat3 Rp;
 if(iRot<3.5){float a=iRot*1.5707963;float s=sin(a),c=cos(a);Rp=mat3(c,0.,-s,0.,1.,0.,s,0.,c);}
 else if(iRot<4.5){Rp=mat3(1.,0.,0.,0.,0.,-1.,0.,1.,0.);}
 else{Rp=mat3(1.,0.,0.,0.,0.,1.,0.,-1.,0.);}
 vec3 p=Rp*(aPos*iScale*iExtra.z)+iPos;
 gl_Position=uMVP*vec4(p,1.);
 vN=uNM*(Rp*aNrm);vUV=aUV;vFace=aFace;vColor=iColor;vState=iExtra.y;vNum=iExtra.x;vMask=iMask;
}`;
const FS=`
precision mediump float;
varying vec3 vN;varying vec2 vUV;varying float vFace;varying float vColor;varying float vState;varying float vNum;varying float vMask;
uniform float uTime;
vec3 pal(int ci,float diff){
 if(ci==0)return mix(vec3(.30,.02,.05),vec3(.78,.10,.14),diff);
 if(ci==1)return mix(vec3(.02,.06,.22),vec3(.13,.38,.80),diff);
 if(ci==2)return mix(vec3(.01,.14,.06),vec3(.07,.55,.27),diff);
 if(ci==3)return mix(vec3(.28,.14,.02),vec3(.85,.60,.14),diff);
 if(ci==4)return mix(vec3(.04,.04,.05),vec3(.32,.27,.17),diff);
 if(ci==6)return mix(vec3(.025,.03,.045),vec3(.09,.11,.16),diff);
 return mix(vec3(.03,.04,.08),vec3(.1,.13,.22),diff);}
void main(){
 vec3 n=normalize(vN);
 float diff=clamp(dot(n,normalize(vec3(.45,.6,.75))),0.,1.)*.75+.25;
 int ci=int(vColor+.5);
 vec3 col=pal(ci,diff);
 float fk=vFace<.5?1.:(vFace<1.5?.8:(vFace<2.5?.38:(vFace<3.5?.52:(vFace<4.5?.66:.3))));
 col*=fk;
 if(vFace<.5&&ci<4){
  vec2 q=abs(vUV-.5)*2.;float r=.35;vec2 dd=max(q-(1.-r),0.);
  if(length(dd)>r)discard;
  col*=1.-.45*smoothstep(.72,1.,max(q.x,q.y));
  col*=1.+.18*max(0.,1.-distance(vUV,vec2(.3,.72))*2.4);
  float mask=vMask;
  for(int k=0;k<9;k++){
   float bit=mod(floor(mask/exp2(float(k))),2.);
   if(bit>.5){
    vec2 g=vec2((mod(float(k),3.)+.5)/3.,1.-(floor(float(k)/3.)+.5)/3.);
    vec2 c=mix(vec2(.5),g,.8);
    float r=.105;
    float dd=distance(vUV,c);
    float inside=smoothstep(r,r*.78,dd);
    col=mix(col,vec3(.945,.915,.85),inside);
    col=mix(col,vec3(.28),.8*inside*smoothstep(r*.9,r*.15,distance(vUV,c+vec2(0.,r*.42))));
    col=mix(col,vec3(1.),.5*inside*smoothstep(r*.25,r*.85,dd)*smoothstep(r*1.05,r*.45,distance(vUV,c-vec2(0.,r*.55))));
    col=mix(col,col*.85,.6*(1.-inside)*smoothstep(r*1.35,r*1.0,dd));
   }}
 }
 if(vState>.5&&vState<1.5){float m=smoothstep(.7,.95,max(abs(vUV.x-.5)*2.,abs(vUV.y-.5)*2.));
  col=mix(col,vec3(1.),m*.9);col*=1.2+.2*sin(uTime*7.);}
 if(vState>1.5&&vState<2.5){float l=dot(col,vec3(.333));col=mix(col,vec3(l)*.7,.55);col*=.5;}
 gl_FragColor=vec4(col,1.);
}`;
function sh(t,src){const s=gl.createShader(t);gl.shaderSource(s,src);gl.compileShader(s);
 if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))console.error(gl.getShaderInfoLog(s));return s;}
const prog=gl.createProgram();
gl.attachShader(prog,sh(gl.VERTEX_SHADER,VS));gl.attachShader(prog,sh(gl.FRAGMENT_SHADER,FS));
gl.linkProgram(prog);gl.useProgram(prog);
/* cube geometry: 6 faces, face0=+Z outer */
const G=(()=>{const P=[],N=[],U=[],F=[],IX=[];
 const faces=[
  {n:[0,0,1],c:[[-.5,-.5,.5],[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5]]},
  {n:[0,1,0],c:[[-.5,.5,.5],[.5,.5,.5],[.5,.5,-.5],[-.5,.5,-.5]]},
  {n:[0,-1,0],c:[[-.5,-.5,-.5],[.5,-.5,-.5],[.5,-.5,.5],[-.5,-.5,.5]]},
  {n:[-1,0,0],c:[[-.5,-.5,-.5],[-.5,-.5,.5],[-.5,.5,.5],[-.5,.5,-.5]]},
  {n:[1,0,0],c:[[.5,-.5,.5],[.5,-.5,-.5],[.5,.5,-.5],[.5,.5,.5]]},
  {n:[0,0,-1],c:[[.5,-.5,-.5],[-.5,-.5,-.5],[-.5,.5,-.5],[.5,.5,-.5]]}];
 faces.forEach((f,fi)=>{const uv=[[0,0],[1,0],[1,1],[0,1]];
  f.c.forEach((p,i)=>{P.push(...p);N.push(...f.n);U.push(...uv[i]);F.push(fi);});
  const b=fi*4;IX.push(b,b+1,b+2,b,b+2,b+3);});
 return {P:new Float32Array(P),N:new Float32Array(N),U:new Float32Array(U),F:new Float32Array(F),IX:new Uint16Array(IX)}})();
function buf(data,t){const b=gl.createBuffer();gl.bindBuffer(t||gl.ARRAY_BUFFER,b);gl.bufferData(t||gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);return b;}
const bP=buf(G.P),bN=buf(G.N),bU=buf(G.U),bF=buf(G.F);
const locP=gl.getAttribLocation(prog,'aPos');gl.enableVertexAttribArray(locP);
const locN=gl.getAttribLocation(prog,'aNrm');gl.enableVertexAttribArray(locN);
const locUv=gl.getAttribLocation(prog,'aUV');gl.enableVertexAttribArray(locUv);
const locF=gl.getAttribLocation(prog,'aFace');gl.enableVertexAttribArray(locF);
const ixBuf=buf(G.IX,gl.ELEMENT_ARRAY_BUFFER);
/* flat quad geometry for rib lattice */
const QG={P:new Float32Array([-.5,-.5,0,.5,-.5,0,.5,.5,0,-.5,.5,0]),
 N:new Float32Array([0,0,1,0,0,1,0,0,1,0,0,1]),
 U:new Float32Array([0,0,1,0,1,1,0,1]),F:new Float32Array([0,0,0,0]),
 IX:new Uint16Array([0,1,2,0,2,3])};
const qbP=buf(QG.P),qbN=buf(QG.N),qbU=buf(QG.U),qbF=buf(QG.F);
const qixBuf=buf(QG.IX,gl.ELEMENT_ARRAY_BUFFER);
/* instance buffer: pos3 scale3 rot color extra3 = 12 floats */
const MAXI=1200,STRIDE=13;
const iData=new Float32Array(MAXI*STRIDE);
const iBuf=gl.createBuffer();
const locIP=gl.getAttribLocation(prog,'iPos'),locIS=gl.getAttribLocation(prog,'iScale'),
 locIR=gl.getAttribLocation(prog,'iRot'),locIC=gl.getAttribLocation(prog,'iColor'),
 locIM=gl.getAttribLocation(prog,'iMask'),locIE=gl.getAttribLocation(prog,'iExtra');
gl.bindBuffer(gl.ARRAY_BUFFER,iBuf);
gl.enableVertexAttribArray(locIP);gl.vertexAttribPointer(locIP,3,gl.FLOAT,false,STRIDE*4,0);vDivisor(locIP,1);
gl.enableVertexAttribArray(locIS);gl.vertexAttribPointer(locIS,3,gl.FLOAT,false,STRIDE*4,12);vDivisor(locIS,1);
gl.enableVertexAttribArray(locIR);gl.vertexAttribPointer(locIR,1,gl.FLOAT,false,STRIDE*4,24);vDivisor(locIR,1);
gl.enableVertexAttribArray(locIC);gl.vertexAttribPointer(locIC,1,gl.FLOAT,false,STRIDE*4,28);vDivisor(locIC,1);
gl.enableVertexAttribArray(locIM);gl.vertexAttribPointer(locIM,1,gl.FLOAT,false,STRIDE*4,32);vDivisor(locIM,1);
gl.enableVertexAttribArray(locIE);gl.vertexAttribPointer(locIE,3,gl.FLOAT,false,STRIDE*4,36);vDivisor(locIE,1);
const uMVP=gl.getUniformLocation(prog,'uMVP'),uNM=gl.getUniformLocation(prog,'uNM'),
 uTime=gl.getUniformLocation(prog,'uTime');
gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.clearColor(0,0,0,0);
/* ghost lines buffer */
let lineBuf=gl.createBuffer(),lineCount=0;
function rebuildLines(){
 const seg=[];
 shells.forEach((sh,li)=>{ if(sh.state!=='ghost')return; const L=LC[li],x=L.fw,y=L.fh,z=L.Rf;
  for(let f=0;f<4;f++){const a=f*Math.PI/2,ca=Math.cos(a),sa=Math.sin(a);
   const rr=p=>[p[0]*ca+p[2]*sa,p[1],-p[0]*sa+p[2]*ca];
   seg.push(...rr([-x,-y,z]),...rr([x,-y,z]), ...rr([x,-y,z]),...rr([x,y,z]),
            ...rr([x,y,z]),...rr([-x,y,z]), ...rr([-x,y,z]),...rr([-x,-y,z]));
}
  const cx=[-x,x,x,-x],cz=[-x,-x,x,x];
  const w=L.fw;[L.H/2,-L.H/2].forEach(yy=>{
   seg.push(-w,yy,-w, w,yy,-w, w,yy,-w, w,yy,w, w,yy,w, -w,yy,w, -w,yy,w, -w,yy,-w);});
  const q=L.S/2,cxq=[-q,q,q,-q],czq=[-q,-q,q,q];
  for(let k=0;k<4;k++){seg.push(cxq[k],-y,czq[k],cxq[k],y,czq[k]);}
  for(let k=0;k<4;k++){const k2=(k+1)%4;
   seg.push(cxq[k],y,czq[k],cxq[k2],y,czq[k2]);
   seg.push(cxq[k],-y,czq[k],cxq[k2],-y,czq[k2]);}
 });
 lineCount=seg.length/3;
 gl.bindBuffer(gl.ARRAY_BUFFER,lineBuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(seg),gl.STATIC_DRAW);
}
const lineProg=gl.createProgram();
const LVS=`attribute vec3 aP;uniform mat4 uMVP;void main(){gl_Position=uMVP*vec4(aP,1.);}`;
const LFS=`precision mediump float;uniform vec4 uC;void main(){gl_FragColor=uC;}`;
gl.attachShader(lineProg,sh(gl.VERTEX_SHADER,LVS));gl.attachShader(lineProg,sh(gl.FRAGMENT_SHADER,LFS));
gl.linkProgram(lineProg);
const lLocP=gl.getAttribLocation(lineProg,'aP'),lMVP=gl.getUniformLocation(lineProg,'uMVP'),lC=gl.getUniformLocation(lineProg,'uC');
/* glass + figure textures via 2D canvas */
function makeTex(w,h,draw){const c=document.createElement('canvas');c.width=w;c.height=h;
 draw(c.getContext('2d'),w,h);const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
 gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,c);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);return t;}
const crackTex=makeTex(128,220,(x,w,h)=>{x.strokeStyle='rgba(255,255,255,.5)';x.lineWidth=1.4;
 for(let i=0;i<5;i++){x.beginPath();let px=Math.random()*w,py=0;x.moveTo(px,py);
  while(py<h){py+=20+Math.random()*30;px+=(Math.random()-.5)*40;x.lineTo(px,py);}x.stroke();}});
/* unique collectible emblems — one per column, spinning behind the glass at finale */
function drawFigIcon(x,i,w,h){
 if(!x.roundRect)x.roundRect=function(a,b,c,d,r){this.rect(a,b,c,d);};
 x.translate(w/2,h/2-14);x.lineCap='round';x.lineJoin='round';
 const G='#e8c56a',GC='#ffe9a3',GR='#3ddc84',GRC='#b8ffd9',RB='#ff6b6b';
 const glow=(c,b)=>{x.shadowColor=c;x.shadowBlur=b||26;};
 if(i===0){glow(GR);x.fillStyle=GR;
  for(let k=0;k<4;k++){x.save();x.rotate(k*Math.PI/2+Math.PI/4);x.beginPath();
   x.moveTo(0,0);x.bezierCurveTo(-38,-30,-30,-78,0,-52);x.bezierCurveTo(30,-78,38,-30,0,0);x.fill();x.restore();}
  x.strokeStyle=GRC;x.lineWidth=10;x.beginPath();x.moveTo(0,10);x.quadraticCurveTo(-8,70,-16,100);x.stroke();}
 else if(i===1){glow(G);x.fillStyle='#7a1220';x.strokeStyle=G;x.lineWidth=7;
  x.beginPath();x.roundRect(-34,-52,68,96,10);x.fill();x.stroke();
  x.fillStyle=GC;glow(GC,14);x.beginPath();
  for(let k=0;k<5;k++){const a=-Math.PI/2+k*2*Math.PI/5,b2=a+Math.PI/5;
   x.lineTo(Math.cos(a)*22,-6+Math.sin(a)*22);x.lineTo(Math.cos(b2)*9,-6+Math.sin(b2)*9);}
  x.closePath();x.fill();}
 else if(i===2){glow(G);x.strokeStyle=G;x.lineWidth=12;
  x.beginPath();x.arc(0,-44,24,0,7);x.stroke();
  x.beginPath();x.moveTo(0,-20);x.lineTo(0,78);x.stroke();
  x.beginPath();x.moveTo(0,78);x.lineTo(26,78);x.moveTo(0,56);x.lineTo(20,56);x.stroke();}
 else if(i===3){glow(G);x.strokeStyle=G;x.lineWidth=9;x.fillStyle='rgba(232,197,106,.14)';
  x.beginPath();x.arc(0,-8,42,0,7);x.fill();x.stroke();
  x.strokeStyle=GC;x.lineWidth=7;glow(GC,14);
  x.beginPath();x.moveTo(0,-8);x.lineTo(0,-34);x.moveTo(0,-8);x.lineTo(20,2);x.stroke();}
 else if(i===4){glow(G);x.strokeStyle=G;x.lineWidth=8;x.fillStyle='rgba(74,163,255,.15)';
  x.beginPath();x.arc(0,-8,42,0,7);x.fill();x.stroke();
  x.fillStyle=RB;glow(RB,16);x.beginPath();x.moveTo(0,-42);x.lineTo(12,-8);x.lineTo(0,26);x.lineTo(-12,-8);x.closePath();x.fill();
  x.fillStyle=GC;x.beginPath();x.moveTo(0,26);x.lineTo(12,-8);x.lineTo(-12,-8);x.closePath();x.fill();}
 else if(i===5){glow('#4aa3ff');x.fillStyle='#4aa3ff';
  x.beginPath();x.ellipse(0,-8,44,26,0,0,7);x.fill();
  x.beginPath();x.moveTo(36,-8);x.lineTo(62,-30);x.lineTo(62,14);x.closePath();x.fill();
  x.fillStyle='#fff';x.beginPath();x.arc(-22,-14,5,0,7);x.fill();}
 else if(i===6){glow(GC);x.strokeStyle=GC;x.lineWidth=8;
  x.beginPath();x.moveTo(-6,84);x.quadraticCurveTo(-14,10,18,-58);x.stroke();
  x.fillStyle='rgba(255,233,163,.85)';x.beginPath();x.moveTo(18,-58);
  x.quadraticCurveTo(46,-16,10,70);x.quadraticCurveTo(-2,10,18,-58);x.fill();
  x.strokeStyle=G;x.lineWidth=3;for(let k=0;k<5;k++){x.beginPath();x.moveTo(16-k*5,-40+k*22);x.lineTo(30-k*4,-30+k*22);x.stroke();}}
 else if(i===7){glow(GR);x.fillStyle='#8a5a2b';x.fillRect(-7,20,14,60);
  x.fillStyle=GR;for(let k=0;k<3;k++){const y=28-k*30,s=46-k*10;
   x.beginPath();x.moveTo(0,y-s);x.lineTo(s,y);x.lineTo(-s,y);x.closePath();x.fill();}}
 else if(i===8){glow(GC);x.fillStyle='#f3e6c8';x.beginPath();x.roundRect(-40,-34,80,68,6);x.fill();
  x.strokeStyle='#b8a888';x.lineWidth=3;for(let k=0;k<3;k++){x.beginPath();x.moveTo(-28,-16+k*16);x.lineTo(28,-16+k*16);x.stroke();}
  x.fillStyle=RB;glow(RB,16);x.beginPath();x.arc(24,22,10,0,7);x.fill();
  x.strokeStyle=RB;x.lineWidth=5;x.beginPath();x.moveTo(24,30);x.lineTo(18,48);x.moveTo(24,30);x.lineTo(30,48);x.stroke();}
 else{glow(G);x.fillStyle=G;
  x.beginPath();x.moveTo(-40,26);x.lineTo(-40,-14);x.lineTo(-20,4);x.lineTo(0,-30);x.lineTo(20,4);x.lineTo(40,-14);x.lineTo(40,26);x.closePath();x.fill();
  x.fillStyle=RB;x.beginPath();x.arc(-20,14,5,0,7);x.fill();
  x.fillStyle='#4aa3ff';x.beginPath();x.arc(0,14,5,0,7);x.fill();
  x.fillStyle=GR;x.beginPath();x.arc(20,14,5,0,7);x.fill();}
}
const figTexCache={};
function figTexFor(col){ if(!figTexCache[col])figTexCache[col]=makeTex(180,260,(x,w,h)=>drawFigIcon(x,col,w,h));
 return figTexCache[col];}
/* quad helper for glass/figure */
const quadProg=gl.createProgram();
const QVS=`attribute vec2 aQ;uniform mat4 uM;varying vec2 vUv;void main(){vUv=aQ*.5+.5;gl_Position=uM*vec4(aQ.x,aQ.y,0.,1.);}`;
const QFS=`precision mediump float;varying vec2 vUv;uniform sampler2D uT;uniform vec4 uTint;uniform float uMode;
void main(){ if(uMode<.5){vec4 t=texture2D(uT,vUv);gl_FragColor=vec4(uTint.rgb+ t.a*vec3(.2),uTint.a+t.a*.1);} else {vec4 t=texture2D(uT,vUv);gl_FragColor=t*uTint.a;}}`;
gl.attachShader(quadProg,sh(gl.VERTEX_SHADER,QVS));gl.attachShader(quadProg,sh(gl.FRAGMENT_SHADER,QFS));
gl.linkProgram(quadProg);
const qBuf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,qBuf);
gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,1,1,-1,1]),gl.STATIC_DRAW);
const qIX=buf(new Uint16Array([0,1,2,0,2,3]),gl.ELEMENT_ARRAY_BUFFER);
const qLoc=gl.getAttribLocation(quadProg,'aQ'),qM=gl.getUniformLocation(quadProg,'uM'),
 qT=gl.getUniformLocation(quadProg,'uT'),qTint=gl.getUniformLocation(quadProg,'uTint'),qMode=gl.getUniformLocation(quadProg,'uMode');
/* ================= view / picking ================= */
let angle=-2.5,vel=0,target=null,drag=null,lastX=0,lastY=0,curScale=1,lastW=0,lastH=0,tiltX=0,tiltTarget=null;
const CAMD=1400,FOV=15*Math.PI/180,REST=-2.5;
function modelMat(){const tr=tiltX*Math.PI/180,L=LC[cur];
 const k=1/(Math.cos(tr)+1.18*(L.S/L.H)*Math.abs(Math.sin(tr)));
 return mMul(mScale(curScale*k),mMul(mRotX((-3+tiltX)*Math.PI/180),mRotY(angle*Math.PI/180)));}
function mvp(){const asp=cv.width/cv.height;
 return mMul(mPersp(FOV,asp,10,2000),mMul(mTrans(0,0,-CAMD),modelMat()));}
function resize(){const dpr=Math.min(devicePixelRatio||1,2);
 cv.width=cv.clientWidth*dpr;cv.height=cv.clientHeight*dpr;}
addEventListener('resize',resize);
function project(p){const v=tP(mvp(),p);
 return [(v[0]*.5+.5)*cv.clientWidth+cv.getBoundingClientRect().left,(1-(v[1]*.5+.5))*cv.clientHeight+cv.getBoundingClientRect().top];}
function pickCube(x,y){
 const r=cv.getBoundingClientRect();
 const nx=((x-r.left)/r.width)*2-1, ny=1-((y-r.top)/r.height)*2;
 const asp=cv.width/cv.height,t=Math.tan(FOV/2);
 const inv=mInv(mMul(mTrans(0,0,-CAMD),modelMat()));
 const o=tP(inv,[0,0,0]);
 let d=tD(inv,[nx*t*asp,ny*t,-1]);
 const dl=Math.hypot(...d);d=d.map(v=>v/dl);
 let best=null,bt=1e9;
 shells[cur].slots.forEach(s=>{const c=s.cube;
  if(c.hidden||c.anim&&c.anim.type==='pop')return;
  const Rm=c.rot<4?((a=>p=>[p[0]*Math.cos(a)-p[2]*Math.sin(a),p[1],p[0]*Math.sin(a)+p[2]*Math.cos(a)])(c.rot*Math.PI/2))
   :(c.rot===4?(p=>[p[0],-p[2],p[1]]):(p=>[p[0],p[2],-p[1]]));
  const ro=[o[0]-c.pos[0],o[1]-c.pos[1],o[2]-c.pos[2]];
  const po=Rm(ro),pd=Rm(d);
  const h=[c.s/2+2,c.s/2+2,c.d/2+6];
  let tmin=0,tmax=1e9;
  for(let i=0;i<3;i++){
   if(Math.abs(pd[i])<1e-8){ if(Math.abs(po[i])>h[i])return; }
   else{let t1=(-h[i]-po[i])/pd[i],t2=(h[i]-po[i])/pd[i];
    if(t1>t2)[t1,t2]=[t2,t1];
    tmin=Math.max(tmin,t1);tmax=Math.min(tmax,t2);
    if(tmin>tmax)return;}}
  if(tmin<bt){bt=tmin;best=c;}
 });
 return best;
}
/* ================= input ================= */
cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,moved:false};lastX=e.clientX;lastY=e.clientY;target=null;tiltTarget=null;});
addEventListener('pointermove',e=>{ if(!drag)return; const dx=e.clientX-lastX, dy=e.clientY-lastY;
 if(Math.abs(e.clientX-drag.x)+Math.abs(e.clientY-drag.y)>7)drag.moved=true;
 if(drag.moved){angle+=dx*.45;vel=dx*.45; tiltX=Math.max(-50,Math.min(50,tiltX+dy*.22));} lastX=e.clientX;lastY=e.clientY;});
addEventListener('pointerup',e=>{ if(drag&&!drag.moved&&!locked&&!finaleOn){
   const c=pickCube(e.clientX,e.clientY);
   if(c)tapCube(c);} drag=null;});
$('bL').onclick=()=>{S.click();target=Math.round((angle-REST)/90)*90-90+REST;};
$('bR').onclick=()=>{S.click();target=Math.round((angle-REST)/90)*90+90+REST;};
$('bU').onclick=()=>{S.click();tiltTarget=Math.min(50,Math.round((tiltX+25)/25)*25);};
$('bD').onclick=()=>{S.click();tiltTarget=Math.max(-50,Math.round((tiltX-25)/25)*25);};
/* ================= gameplay ================= */
function hud(){$('stScore').textContent=score;$('stMovesV').textContent=moves;$('stCombo').textContent=combo;
 $('stCubes').textContent=shells[cur].slots.length-shells[cur].removed;$('comboX').style.display=mult===2?'inline-block':'none';
 $('stLayerV').textContent=(cur+1)+'/4 '+curOps[cur];
 const si=$('shellsInd');if(si)si.innerHTML=[0,1,2,3].map(i=>'<span class="sh'+(i<cur?' done':(i===cur?' cur':''))+'">'+(i+1)+'</span>').join('');
 const pb=$('pbarI');if(pb&&shells[cur])pb.style.width=Math.round(100*(1-shells[cur].removed/shells[cur].slots.length))+'%';}
function shake(big){const s=$('shaker');s.classList.remove('shakeS','shakeB');void s.offsetWidth;
 s.classList.add(big?'shakeB':'shakeS');}
/* live assembly-explanation rows: equation + triple */
function fSlot(s){return s?'<b style="color:'+COLORS[s.col]+';text-shadow:0 0 10px '+COLORS[s.col]+'">'+s.n+'</b>':'<b>?</b>';}
function eqPossible(){
 if(selected.length<2)return true;
 const a=selected[0].n,b=selected[1].n;
 if(selected.length===2){for(let x=1;x<=9;x++)if(eqOk(curOp,[a,b,x]))return true;return false;}
 return eqOk(curOp,[a,b,selected[2].n]);}
function trPossible(){return selected.every(s=>s.n===selected[0].n&&s.col===selected[0].col);}
function updateFormulas(force){
 if(!force&&performance.now()<formulaLock)return;
 const op=curOp,a=selected[0],b=selected[1],c=selected[2];
 const q='<b>?</b>';
 const eq=eqPossible(),tr=selected.length?trPossible():true;
 const full=selected.length===3;
 const eS=(eq||full),tS=(tr||full);
 const EQS=eq?'=':'<span class="neq">=<i></i></span>';
 const AMP=tr?'&':'<span class="neq">&<i></i></span>';
 $('hint1').innerHTML=T('solve')+': «'+(eS?fSlot(a):q)+'» '+EQS+' «'+(eS?fSlot(b):q)+'» '+op+' «'+(eS?fSlot(c):q)+'»';
 $('hint2').innerHTML=T('row3')+': «'+(tS?fSlot(a):q)+'» '+AMP+' «'+(tS?fSlot(b):q)+'» '+AMP+' «'+(tS?fSlot(c):q)+'»';
}
function tapCube(c){
 const s=c.slot;
 if(autoOn)return;
 if(selected.length>=3)return;
 if(selected.includes(s)){selected=selected.filter(x=>x!==s);S.desel();updateFormulas();return;}
 selected.push(s);S.sel();updateFormulas();
 if(selected.length===3)setTimeout(evaluate,140);
}
function deselectAll(){selected=[];updateFormulas();}
function opCheck(op,r,x,y){
 if(op==='+')return x+y===r;
 if(op==='−')return x-y===r||y-x===r;
 if(op==='×')return x*y===r;
 return (y>0&&x%y===0&&x/y===r)||(x>0&&y%x===0&&y/x===r);}
/* order-independent: the three tapped cubes form the equation in ANY tap order & colors */
function eqOk(op,v){const a=v[0],b=v[1],c=v[2];
 if(op==='+')return a===b+c||b===a+c||c===a+b;
 if(op==='−')return Math.abs(b-c)===a||Math.abs(a-c)===b||Math.abs(a-b)===c;
 if(op==='×')return a===b*c||b===a*c||c===a*b;
 return opCheck(op,a,b,c)||opCheck(op,b,a,c)||opCheck(op,c,a,b);}
function evaluate(){
 if(locked)return;const [a,b,c]=selected;
 const isTriple=a.n===b.n&&b.n===c.n&&a.col===b.col&&b.col===c.col;
 const isEq=eqOk(curOp,[a.n,b.n,c.n]);
 if(!isTriple&&!isEq){
  locked=true;moves--;combo=0;mult=1;S.err();shake(false);
  const [sx,sy]=project(a.cube.pos);
  ftext(sx,sy,T('err'));
  formulaLock=performance.now()+500;updateFormulas(true);
  setTimeout(()=>{deselectAll();locked=false;hud();checkFail();setTimeout(updateFormulas,80);},450);
  return;}
 formulaLock=performance.now()+1000;updateFormulas(true);
 setTimeout(updateFormulas,1080);
 locked=true;
 if(isTriple)doTriple([a,b,c]);else doEquation([a,b,c]);
}
function orphansOf(set){
 const out=[];shells[cur].eqs.forEach(tr=>{const rem=tr.filter(s=>set.has(s)),rest=tr.filter(s=>!set.has(s));
  if(rem.length&&rest.length)rest.forEach(s=>out.push(s));});
 return out;}
function popCube(s,delay,kind){
 const c=s.cube;
 setTimeout(()=>{const [cx,cy]=project(c.pos);
  burst(cx,cy,COLORS[s.col],kind==='triple'?22:14,kind==='triple'?4.5:3);
  S.tick(delay/70);shake(false);},delay);
 c.anim={type:'pop',t0:performance.now()+delay};
 s.removed=true;shells[cur].removed++;rowCheck(s,project(c.pos)[0],project(c.pos)[1]);hud();
}
function doEquation(tr){
 const set=new Set(tr);let gain=(3*10+30);
 combo++;if(combo>=3&&mult===1){mult=2;ftext(innerWidth/2,innerHeight*.3,T('comboX'),true);}
 gain*=mult;score+=gain;
 const [sx,sy]=project(tr[0].cube.pos);ftext(sx,sy-10,'+'+gain);
 S.clear();deselectAll();
 tr.forEach((s,i)=>popCube(s,i*70,'eq'));
 finishWaves(set,orphansOf(set),450);
}
function doTriple(tr){
 const set=new Set(tr);let gain=(3*15+100)*mult;score+=gain;moves+=2;
 S.triple();shake(true);
 const [sx,sy]=project(tr[0].cube.pos);
 ftext(sx,sy-10,T('triple'),true);
 ftext(innerWidth/2,innerHeight*.25,T('plus2'));
 deselectAll();
 tr.forEach((s,i)=>popCube(s,i*80,'triple'));
 finishWaves(set,orphansOf(set),500);
}
function finishWaves(set,orph,t0w){
 if(orph.length){
  setTimeout(()=>ftext(innerWidth/2,innerHeight*.35,T('cascade'),true),t0w);
  orph.forEach((s,i)=>{set.add(s);popCube(s,t0w+i*90,'casc');});
  setTimeout(()=>S.layer(),t0w+200);
  score+=orph.length*20*mult;
  setTimeout(afterWaves,t0w+orph.length*90+550);
 } else setTimeout(afterWaves,t0w+550);
}
function afterWaves(){
 locked=false;hud();
 if(shells[cur].removed>=shells[cur].slots.length){
  autoOn=false;
  score+=1000;hud();S.fanfare();confetti(70);shake(true);
  ftext(innerWidth/2,innerHeight*.35,T('shellBonus'),true);
  locked=true;
  setTimeout(()=>{
   if(cur<3){shells[cur].state='ghost';rebuildLines();
    cur++;shells[cur].state='active';
    moves=MOVES[cur];curOp=curOps[cur];selected=[];combo=0;mult=1;
    curScale=TSCALE[cur];
    shells[cur].slots.forEach((s,i)=>{s.cube.anim={type:'spawn',t0:performance.now(),delay:i*10};s.cube.hidden=false;});
    applyLang();hud();locked=false;
   } else finale();
  },1500);
  return;}
 checkFail();
}
function checkFail(){
 if(moves<=0&&shells[cur].removed<shells[cur].slots.length){locked=true;
  ftext(innerWidth/2,innerHeight*.4,T('noMoves'),true);S.err();
  setTimeout(()=>resetLayer(),1400);}
}
function resetLayer(){
 const li=cur;
 shells[li]=genShell(curOp);shells[li].state='active';
 const L=LC[li];
 shells[li].slots.forEach((s,idx)=>{
  s.cube={li,idx,pos:slotGeom(L,s),rot:s.f,s:L.c,d:L.d,n:s.n,col:s.col,slot:s,
    anim:{type:'spawn',t0:performance.now(),delay:idx*10},hidden:false};
  cubes=cubes.filter(c=>!(c.li===li));cubes.push(s.cube);
 });
 selected=[];locked=false;combo=0;mult=1;moves=MOVES[li];hud();
}
function rowCheck(s,x,y){
 if(s.f>3)return; /* ring bonus only for the 4 side rows */
 const sh=shells[cur],r=s.r;
 sh.rowDone[r]=(sh.rowDone[r]||0)+1;
 if(sh.rowDone[r]===12){score+=200*mult;ftext(x,y-30,T('layerBonus'),true);S.layer();}
}
function finale(){
 finaleOn=true;autoOn=false;gameplayStop();
 S.crack();shake(true);confetti(140);setTimeout(()=>S.fanfare(),500);
 let fw=0;const iv=setInterval(()=>{firework();if(++fw>5)clearInterval(iv);},400);
 runTime=(performance.now()-t0)/1000|0;
 setTimeout(()=>{ if(MB.onFinale)MB.onFinale({score,moves,time:runTime,col:colIdx}); },1600);
}
/* ================= i18n / start ================= */
function applyLang(){
 updateFormulas(true);
 $('dragHint').textContent=T('drag');
 $('bAuto').textContent=T('btn_auto');
}
function startAll(ops){
 curOps=(ops&&ops.length===4)?ops.slice():OPS.slice();
 shells=[genShell(curOps[0]),genShell(curOps[1]),genShell(curOps[2]),genShell(curOps[3])];
 shells.forEach((s,i)=>s.state=i===0?'active':'deep');
 cur=0;curOp=curOps[0];selected=[];locked=false;score=0;moves=MOVES[0];combo=0;mult=1;finaleOn=false;autoOn=false;formulaLock=0;
 curScale=TSCALE[0];t0=performance.now();
 buildCubeData();
 shells.forEach(sh=>sh.slots.forEach((s,i)=>{s.cube.anim={type:'spawn',t0:performance.now(),delay:i*10};}));
 rebuildLines();
 P=[];applyLang();hud();
}
/* ================= premium auto-assemble ================= */
function remainingSlots(){return shells[cur].slots.filter(s=>!s.removed);}
function findAutoSet(){
 const rem=remainingSlots();
 const grp={};rem.forEach(s=>{(grp[s.n+'_'+s.col]=grp[s.n+'_'+s.col]||[]).push(s)});
 for(const k in grp)if(grp[k].length>=3)return grp[k].slice(0,3);
 let best=null;
 for(let i=0;i<rem.length;i++)for(let j=i+1;j<rem.length;j++)for(let k=j+1;k<rem.length;k++){
  const a=rem[i],b=rem[j],c=rem[k];
  if(eqOk(curOp,[a.n,b.n,c.n])){const orph=orphansOf(new Set([a,b,c])).length;
   if(!best||orph>best.orph){best={set:[a,b,c],orph};if(orph>0)return best.set;}}}
 return best&&best.set;
}
function autoStep(){
 if(!autoOn||finaleOn)return;
 if(locked){setTimeout(autoStep,400);return;}
 let set=findAutoSet(),forced=false;
 if(!set){const rem=remainingSlots();
  if(rem.length){set=rem.slice(0,3);forced=true;} }
 if(!set){autoOn=false;ftext(innerWidth/2,innerHeight*.3,T('auto_no'),true);return;}
 const orph=orphansOf(new Set(set));
 const cnt={};[...set,...orph].forEach(s=>cnt[s.f]=(cnt[s.f]||0)+1);
 let bf=0,bc=0;for(const f in cnt)if(cnt[f]>bc){bc=cnt[f];bf=+f;}
 const desired=(bf<4?bf*90:0)+REST;
 const delta=((desired-angle)%360+540)%360-180;
 if(Math.abs(delta)>2)target=angle+delta;
 setTimeout(()=>{ if(!autoOn||finaleOn)return;
  selected=set.slice();formulaLock=performance.now()+1100;updateFormulas(true);
  setTimeout(()=>{ if(!autoOn||finaleOn)return;
   if(forced)doEquation(set);else evaluate();
   setTimeout(autoStep,1900); },400);
 },700);
}
/* manual equation tap-check: finds first intact equation, taps result-first via real evaluate() */
function tapCheck(){
 if(locked||finaleOn||autoOn)return -1;
 const sh=shells[cur];
 for(const tr of sh.eqs){
  if(tr.some(s=>s.removed))continue;
  selected=tr.slice();updateFormulas(true);
  const before=sh.removed;evaluate();
  return sh.removed>before?sh.removed-before:-1;
 }
 return -1;}
$('bAuto').onclick=()=>{ if(autoOn||finaleOn||locked)return; S.click();autoOn=true;autoStep(); };
/* ================= render loop ================= */
function easeOutBack(p){const c=1.70158;return 1+ (c+1)*Math.pow(p-1,3)+c*Math.pow(p-1,2);}
function fillInstances(now){
 let n=0;
 const put=(pos,scale,rot,color,mask,extra)=>{ if(n>=MAXI)return;const o=n*STRIDE;
  iData[o]=pos[0];iData[o+1]=pos[1];iData[o+2]=pos[2];
  iData[o+3]=scale[0];iData[o+4]=scale[1];iData[o+5]=scale[2];
  iData[o+6]=rot;iData[o+7]=color;
  iData[o+8]=mask;iData[o+9]=extra[0];iData[o+10]=extra[1];iData[o+11]=extra[2];n++;};
 cubes.forEach(c=>{
  const sh=shells[c.li];
  if(sh.state==='ghost')return;
  let sc=1,state=0;
  if(sh.state==='deep')state=2;
  if(selected.includes(c.slot))state=1;
  if(c.hidden){return;}
  if(c.anim){
   const p=(now-c.anim.t0-(c.anim.delay||0));
   if(c.anim.type==='spawn'){ if(p<0)sc=0; else if(p<450)sc=Math.max(.001,easeOutBack(p/450)); else c.anim=null; }
   else { if(p<0)sc=1;
    else if(p<500){ sc=p<175?1+(p/175)*.3:1.3*(1-(p-175)/325); state=1; }
    else {c.hidden=true;return;} }
  }
  put(c.pos,[c.s,c.s,c.d],c.rot,c.col,PIPMASK[c.n],[c.n,state,Math.max(sc,.001)]);
 });
 // frame: open cap rims + corner pillars (box geometry)
 shells.forEach((sh,li)=>{ if(sh.state==='ghost')return; const L=LC[li],st=sh.state==='deep'?2:0;
  [1,-1].forEach(sg=>{const y=sg*(L.H/2-5),m=L.S/2-5;
   put([0,y,m],[L.S,10,10],0,6,0,[0,st,1]); put([0,y,-m],[L.S,10,10],0,6,0,[0,st,1]);
   put([m,y,0],[10,10,L.S-20],0,6,0,[0,st,1]); put([-m,y,0],[10,10,L.S-20],0,6,0,[0,st,1]);});
  const q=L.S/2-L.p/2;
  [[q,q],[-q,q],[q,-q],[-q,-q]].forEach(cc=>put([cc[0],0,cc[1]],[L.p,L.H-2*L.p,L.p],0,6,0,[0,st,1]));
 });
 // core box
 if(!finaleOn)put([0,0,0],[(LC[3].Rf-10)*2,LC[3].H-20,(LC[3].Rf-10)*2],0,5,0,[0,0,1]);
 const nc=n;
 // rib lattice: dark slits between cubes (flat quads)
 shells.forEach((sh,li)=>{ if(sh.state==='ghost')return; const L=LC[li],st=sh.state==='deep'?2:0;
  const e=L.c+L.g, rr=L.Rf+0.5;
  for(let f=0;f<4;f++){const a=f*Math.PI/2,ca=Math.cos(a),sa=Math.sin(a);
   const rp=(lx,ly,w,h)=>{const x=lx*ca+rr*sa, z=-lx*sa+rr*ca;
    put([x,ly,z],[w,h,1],f,6,0,[0,st,1]);};
   rp(-(L.fw-L.g/2),0,L.g,2*L.fh); rp(L.fw-L.g/2,0,L.g,2*L.fh);
   rp(0,-(L.fh-L.g/2),2*L.fw,L.g); rp(0,L.fh-L.g/2,2*L.fw,L.g);
   [-e/2,e/2].forEach(vx=>rp(vx,0,L.g,2*L.fh));
   [-1.5,-.5,.5,1.5].forEach(k=>rp(0,k*e,2*L.fw,L.g));
  }
  // top & bottom rib lattice
  const yt=L.H/2+0.5;
  [[4,yt],[5,-yt]].forEach(pr=>{const rc=pr[0],yy=pr[1];
   put([e/2,yy,0],[L.g,2*L.fw,1],rc,6,0,[0,st,1]); put([-e/2,yy,0],[L.g,2*L.fw,1],rc,6,0,[0,st,1]);
   put([0,yy,e/2],[2*L.fw,L.g,1],rc,6,0,[0,st,1]); put([0,yy,-e/2],[2*L.fw,L.g,1],rc,6,0,[0,st,1]);});
 });
 return [nc,n-nc];
}
function loop(){
 requestAnimationFrame(loop);
 const now=performance.now();
 if(!MBactive)return;
 if(target!==null){angle+=(target-angle)*.12;if(Math.abs(target-angle)<.1){angle=target;target=null;}}
 if(tiltTarget!==null){tiltX+=(tiltTarget-tiltX)*.12;if(Math.abs(tiltTarget-tiltX)<.1){tiltX=tiltTarget;tiltTarget=null;}}
 else if(!drag){angle+=vel;vel*=.94;if(Math.abs(vel)<.01)vel=0;}
 if(cv.clientWidth!==lastW||cv.clientHeight!==lastH){lastW=cv.clientWidth;lastH=cv.clientHeight;resize();}
 gl.viewport(0,0,cv.width,cv.height);
 gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 const M=mvp();
 gl.useProgram(prog);
 gl.uniformMatrix4fv(uMVP,false,M);
 const mm=modelMat();
 gl.uniformMatrix3fv(uNM,false,new Float32Array([mm[0],mm[1],mm[2],mm[4],mm[5],mm[6],mm[8],mm[9],mm[10]]));
 gl.uniform1f(uTime,now/1000);
 const [nc,nq]=fillInstances(now);
 gl.bindBuffer(gl.ARRAY_BUFFER,bP);gl.vertexAttribPointer(locP,3,gl.FLOAT,false,0,0);
 gl.bindBuffer(gl.ARRAY_BUFFER,bN);gl.vertexAttribPointer(locN,3,gl.FLOAT,false,0,0);
 gl.bindBuffer(gl.ARRAY_BUFFER,bU);gl.vertexAttribPointer(locUv,2,gl.FLOAT,false,0,0);
 gl.bindBuffer(gl.ARRAY_BUFFER,bF);gl.vertexAttribPointer(locF,1,gl.FLOAT,false,0,0);
 gl.bindBuffer(gl.ARRAY_BUFFER,iBuf);gl.bufferData(gl.ARRAY_BUFFER,iData,gl.DYNAMIC_DRAW);
 vDivisor(locIP,1);vDivisor(locIS,1);vDivisor(locIR,1);vDivisor(locIC,1);vDivisor(locIM,1);vDivisor(locIE,1);
 gl.vertexAttribPointer(locIP,3,gl.FLOAT,false,STRIDE*4,0);
 gl.vertexAttribPointer(locIS,3,gl.FLOAT,false,STRIDE*4,12);
 gl.vertexAttribPointer(locIR,1,gl.FLOAT,false,STRIDE*4,24);
 gl.vertexAttribPointer(locIC,1,gl.FLOAT,false,STRIDE*4,28);
 gl.vertexAttribPointer(locIM,1,gl.FLOAT,false,STRIDE*4,32);
 gl.vertexAttribPointer(locIE,3,gl.FLOAT,false,STRIDE*4,36);
 gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ixBuf);
 drawInst(36,nc);
 // rib lattice pass (flat quads from the same instance buffer)
 if(nq){
  gl.bindBuffer(gl.ARRAY_BUFFER,qbP);gl.vertexAttribPointer(locP,3,gl.FLOAT,false,0,0);
  gl.bindBuffer(gl.ARRAY_BUFFER,qbN);gl.vertexAttribPointer(locN,3,gl.FLOAT,false,0,0);
  gl.bindBuffer(gl.ARRAY_BUFFER,qbU);gl.vertexAttribPointer(locUv,2,gl.FLOAT,false,0,0);
  gl.bindBuffer(gl.ARRAY_BUFFER,qbF);gl.vertexAttribPointer(locF,1,gl.FLOAT,false,0,0);
  const off=nc*STRIDE*4;
  gl.bindBuffer(gl.ARRAY_BUFFER,iBuf);
  gl.vertexAttribPointer(locIP,3,gl.FLOAT,false,STRIDE*4,off);
  gl.vertexAttribPointer(locIS,3,gl.FLOAT,false,STRIDE*4,off+12);
  gl.vertexAttribPointer(locIR,1,gl.FLOAT,false,STRIDE*4,off+24);
  gl.vertexAttribPointer(locIC,1,gl.FLOAT,false,STRIDE*4,off+28);
  gl.vertexAttribPointer(locIM,1,gl.FLOAT,false,STRIDE*4,off+32);
  gl.vertexAttribPointer(locIE,3,gl.FLOAT,false,STRIDE*4,off+36);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,qixBuf);
  drawInst(6,nq);
 }
 // ghost lines
 if(lineCount){
  gl.useProgram(lineProg);gl.disable(gl.CULL_FACE);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
  gl.depthMask(false);
  gl.uniformMatrix4fv(lMVP,false,M);gl.uniform4f(lC,.91,.77,.42,.5);
  vDivisor(lLocP,0);
  gl.bindBuffer(gl.ARRAY_BUFFER,lineBuf);
  gl.enableVertexAttribArray(lLocP);gl.vertexAttribPointer(lLocP,3,gl.FLOAT,false,0,0);
  gl.drawArrays(gl.LINES,0,lineCount);
  gl.depthMask(true);gl.disable(gl.BLEND);gl.enable(gl.CULL_FACE);
 }
 // glass & figure
 if(finaleOn){
  gl.useProgram(quadProg);gl.disable(gl.CULL_FACE);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
  gl.depthMask(false);
  const GW=80,GH=150,GR=40;
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,crackTex);gl.uniform1i(qT,0);
  gl.uniform1f(qMode,0);gl.uniform4f(qTint,.5,.8,1.,.16);
  vDivisor(qLoc,0);
  gl.bindBuffer(gl.ARRAY_BUFFER,qBuf);gl.enableVertexAttribArray(qLoc);gl.vertexAttribPointer(qLoc,2,gl.FLOAT,false,0,0);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,qIX);
  for(let f=0;f<4;f++){
   const mm2=mMul(M,mMul(mRotY(f*Math.PI/2),mMul(mTrans(0,0,GR),mScale(1))));
   const S2=mMul(mm2,new Float32Array([GW/2,0,0,0,0,GH/2,0,0,0,0,1,0,0,0,0,1]));
   gl.uniformMatrix4fv(qM,false,S2);gl.drawElements(gl.TRIANGLES,6,gl.UNSIGNED_SHORT,0);}
  // figure spinning — unique emblem of this column
  gl.bindTexture(gl.TEXTURE_2D,figTexFor(colIdx));gl.uniform1f(qMode,1);gl.uniform4f(qTint,1,1,1,1);
  const fm=mMul(M,mMul(mRotY(now/1000),mScale(1)));
  const FS2=mMul(fm,new Float32Array([56,0,0,0,0,80,0,0,0,0,1,0,0,0,8,1]));
  gl.uniformMatrix4fv(qM,false,FS2);gl.drawElements(gl.TRIANGLES,6,gl.UNSIGNED_SHORT,0);
  gl.depthMask(true);gl.disable(gl.BLEND);gl.enable(gl.CULL_FACE);
 }
 // 2D overlay
 fctx.clearRect(0,0,fx.width,fx.height);
 for(let i=P.length-1;i>=0;i--){const p=P[i];p.l-=.02;p.x+=p.vx;p.y+=p.vy;
  if(p.t==='conf'){p.vy+=.06;p.r+=p.vr;p.vx*=.99;}else{p.vy+=.05;p.vx*=.97;}
  if(p.l<=0||p.y>fx.height+30){P.splice(i,1);continue;}
  fctx.globalAlpha=Math.max(0,Math.min(1,p.l));
  if(p.t==='conf'){fctx.save();fctx.translate(p.x,p.y);fctx.rotate(p.r);fctx.fillStyle=p.c;
   fctx.fillRect(-p.s/2,-p.s/3,p.s,p.s*.66);fctx.restore();}
  else{fctx.shadowBlur=8;fctx.shadowColor=p.c;fctx.fillStyle=p.c;fctx.beginPath();
   fctx.arc(p.x,p.y,p.s*p.l,0,6.28);fctx.fill();fctx.shadowBlur=0;}}
 fctx.globalAlpha=1;
}
resize();requestAnimationFrame(loop);
window.MB={
 start(col,ops){colIdx=col||0;autoOn=false;selected=[];formulaLock=0;
  startAll(ops);MBactive=true;gameplayStart();hud();applyLang();},
 stop(){MBactive=false;autoOn=false;gameplayStop();},
 pause(){autoOn=false;},
 setActive(v){MBactive=!!v; if(v)gameplayStart(); else gameplayStop();},
 dbg(){return {removed:shells[cur]?shells[cur].removed:0,total:shells[cur]?shells[cur].slots.length:0,
  active:MBactive,cur,angle,tiltX,op:curOp,
  auto(){autoOn=true;autoStep();}};},
 active:()=>MBactive,
 tapCheck(){return tapCheck()},
 get score(){return score},
 resize,
 refresh:applyLang,
};
