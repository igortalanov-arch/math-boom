/* Мат-Бум UI: screens, saves, menu/hall/museum/help, chrome toggles */
'use strict';
const VERSION='1.0.6', COLS=10, YEAR=2026;
const $u=id=>document.getElementById(id);
const OPS4=['+','−','×','÷'];
function opsFor(col){return [0,1,2,3].map(i=>OPS4[(i+col)%4]);}

/* ------------------------- progress & prefs ------------------------- */
let PROG={best:new Array(COLS).fill(0),unlocked:new Array(COLS).fill(false)};
function loadLocal(){
 try{const r=JSON.parse(localStorage.getItem('matbum_v1'));
  if(r&&r.best)PROG={best:r.best.slice(0,COLS),unlocked:!!r.unlocked?r.unlocked.slice(0,COLS):PROG.unlocked};
 }catch(e){}
 try{const t=localStorage.getItem('matbum_theme');if(t==='light'||t==='dark')applyTheme(t,false);}catch(e){}
}
function saveProg(cloud){
 try{localStorage.setItem('matbum_v1',JSON.stringify(PROG));}catch(e){}
 if(cloud!==false)cloudSave(PROG);
}
async function mergeCloud(){
 const c=await cloudLoad();
 if(!c)return;
 for(let i=0;i<COLS;i++){
  PROG.best[i]=Math.max(PROG.best[i]||0,c.best&&c.best[i]||0);
  PROG.unlocked[i]=(PROG.unlocked[i]||!!(c.unlocked&&c.unlocked[i]));
 }
 try{localStorage.setItem('matbum_v1',JSON.stringify(PROG));}catch(e){}
}

/* ----------------------------- theming ------------------------------ */
let theme='dark';
function applyTheme(t,save){theme=t;document.documentElement.setAttribute('data-theme',t);
 if(save!==false){try{localStorage.setItem('matbum_theme',t);}catch(e){}}
 paintChrome();if(curScreen==='museum')renderMuseum();}

/* ------------------------------ screens ----------------------------- */
let curScreen='start',interQ=false;
function showScreen(id){
 curScreen=id;
 document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('on',s.id==='scr-'+id));
 $u('btn-back').hidden=(id==='start');
 if(id==='select')renderSelect();
 if(id==='hall')renderHall();
 if(id==='museum')renderMuseum();
 if(id==='help')renderHelp();
 if(id==='start'||id==='select'){ if(interQ){interQ=false;showInterstitial();} }
}
function backFrom(){
 if(curScreen==='game'){openPause();return;}
 showScreen('start');
}

/* ------------------------------ chrome ------------------------------ */
function setBtnIcon(btn,name){
 let img=btn.querySelector('img.ico');
 if(!img){img=iconImg(name,'ico');btn.insertBefore(img,btn.firstChild);}
 else img.src=ICONS[name]||'';
}
function paintChrome(){
 $u('lang-lbl').textContent=T('lang_btn');
 $u('btn-lang').title=lang()==='ru'?'English':'Русский';
 setBtnIcon($u('btn-sound'),'ui-sound');
 $u('btn-sound').classList.toggle('off',!isSoundOn());
 $u('btn-sound').title=T(isSoundOn()?'sound_on':'sound_off');
 setBtnIcon($u('btn-lang'),'ui-lang');
 setBtnIcon($u('btn-theme'),theme==='dark'?'ui-sun':'ui-moon');
 $u('btn-theme').title=T(theme==='dark'?'theme_light':'theme_dark');
 const bb=$u('btn-back');
 setBtnIcon(bb,'ui-back');
 bb.title=T('btn_back');
}
function paintStatic(){
 $u('m-logo').textContent=T('appName');
 $u('m-sub').textContent=T('appSub');
 [['b-play','btn_play','ui-play'],['b-hall','btn_hall','ui-ach'],['b-museum','btn_museum','ui-museum'],['b-help','btn_help','ui-help']]
  .forEach(a=>{const b=$u(a[0]);setBtnIcon(b,a[2]);
   let sp=b.querySelector('span.lbl');if(!sp){sp=document.createElement('span');sp.className='lbl';b.appendChild(sp);}
   sp.textContent=T(a[1]);});
 $u('m-ver').textContent=T('version_fmt',{v:VERSION});
 $u('hud-logo').innerHTML=T('appName')+'<small id="hud-sub">'+T('appSub')+' · v'+VERSION+'</small>';
 document.title=T('appName')+' '+T('appSub');
 $u('sel-title').textContent=T('choose_col');
 $u('hall-title').textContent=T('hall_title');
 $u('hall-sub').textContent=T('hall_sub');
 $u('mus-title').textContent=T('museum_title');
 $u('mus-sub').textContent=T('museum_sub');
 $u('help-title').textContent=T('help_title');
 $u('help-sub').textContent=T('help_sub');
 $u('help-footer').textContent=T('author')+' © '+YEAR+' · '+T('version_fmt',{v:VERSION});
 $u('p-title').textContent=T('pause_title');
 $u('p-resume').textContent=T('pause_resume');
 $u('p-exit').textContent=T('pause_exit');
 $u('f-congr').textContent=T('congrats');
 $u('fin-menu').textContent=T('menu');
 $u('fin-again').textContent=T('btn_again');
 $u('fin-next').textContent=T('btn_next');
 document.querySelectorAll('#hud [data-t]').forEach(sp=>{sp.textContent=T(sp.dataset.t);});
 paintChrome();
 if(window.MB)MB.refresh();
}

/* ------------------------------ select ------------------------------ */
function renderSelect(){
 const g=$u('colgrid');g.innerHTML='';
 for(let i=0;i<COLS;i++){
  const b=document.createElement('button');b.className='colcard'+(PROG.unlocked[i]?'':' locked');b.type='button';
  b.innerHTML='<span class="num">'+(i+1)+'</span><img class="fig" alt="" src="'+FIGIMG[i]+'">'
   +'<div class="nm">'+T('fig'+i)+'</div>'
   +'<div class="bst">'+(PROG.best[i]?T('best')+': '+PROG.best[i]:'—')+'</div>'
   +(PROG.unlocked[i]?'<span class="done">✔</span>':'');
  b.addEventListener('click',()=>{S.click();startCol(i);});
  g.appendChild(b);
 }
}

/* ------------------------------- hall ------------------------------- */
function renderHall(){
 const host=$u('hall-list');host.innerHTML='';
 const rows=[];for(let i=0;i<COLS;i++)if(PROG.best[i]>0)rows.push([i,PROG.best[i]]);
 rows.sort((a,b)=>b[1]-a[1]);
 if(!rows.length)host.innerHTML='<p class="sub" style="margin-top:14px">'+T('hall_empty')+'</p>';
 rows.forEach((r,k)=>{
  const d=document.createElement('div');d.className='hallrow';
  d.innerHTML='<span class="rk">'+(k+1)+'</span><img width="30" height="30" style="border-radius:8px;object-fit:cover" alt="" src="'+FIGIMG[r[0]]+'">'
   +'<span class="nm">'+T('column')+' '+(r[0]+1)+' · '+T('fig'+r[0])+'</span>'
   +'<span class="sc">'+r[1]+'</span>';
  host.appendChild(d);
 });
 const tot=PROG.best.reduce((a,b)=>a+b,0);
 const t=$u('hall-total');t.textContent=T('hall_total')+': '+tot;
 lbTop(5).then(list=>{
  const ya=$u('hall-ya');ya.innerHTML='';
  if(!list||!list.length)return;
  const h=document.createElement('div');h.className='card';h.innerHTML='<h2>Yandex Games — TOP 5</h2>';
  list.forEach((e,i)=>{const d=document.createElement('div');d.className='hallrow';
   d.innerHTML='<span class="rk">'+(i+1)+'</span><span class="nm">'+e.name+'</span><span class="sc">'+e.score+'</span>';
   h.appendChild(d);});
  ya.appendChild(h);
 });
}

/* ------------------------------ museum ------------------------------ */
function renderMuseum(){
 const g=$u('musgrid');g.innerHTML='';
 for(let i=0;i<COLS;i++){
  const un=PROG.unlocked[i];
  const d=document.createElement('div');d.className='muscard ped'+(un?'':' locked');
  d.innerHTML='<div class="dome'+(un?'':' lockdome')+'"><img alt="" src="'+(un?FIGIMG[i]:ICONS['ui-lock'])+'"></div>'
   +'<div class="base"></div>'
   +'<div class="plate">'+T('column')+' '+(i+1)+' · '+(un?T('fig'+i):'?')+'</div>'
   +(un?'':'<div class="bst sub" style="font-size:9.5px;margin-top:2px">'+T('museum_locked')+'</div>');
  d.addEventListener('click',()=>openFig(i));
  g.appendChild(d);
 }
}
function openFig(i){
 if(!PROG.unlocked[i])return; /* locked: no big card at all */
 $u('fig-big').src=FIGIMG[i];
 $u('fig-big').style.filter=PROG.unlocked[i]?'':'grayscale(1) brightness(.6)';
 $u('fig-big-name').textContent=T('column')+' '+(i+1)+' — '+T('fig'+i);
 $u('fig-big-sub').textContent=PROG.unlocked[i]?T('cleared')+' ✔':T('museum_locked');
 openOv('ov-fig');
}
$u('fig-close').onclick=()=>closeOv('ov-fig');

/* ------------------------------- help ------------------------------- */
function renderHelp(){
 const host=$u('help-body');host.innerHTML='';
 const keys=[['help_goal_t','help_goal'],['help_col_t','help_col'],['help_cubes_t','help_cubes'],
  ['help_eq_t','help_eq'],['help_tr_t','help_tr'],['help_bonus_t','help_bonus'],
  ['help_ctrl_t','help_ctrl'],['help_auto_t','help_auto'],['help_mus_t','help_mus']];
 keys.forEach(p=>{
  const c=document.createElement('div');c.className='card';
  c.innerHTML='<h2>'+T(p[0])+'</h2><p>'+T(p[1])+'</p>';
  host.appendChild(c);
 });
}

/* ---------------------------- game flow ----------------------------- */
let lastFinale=null;
/* tutorial: step-by-step on first ever run */
const TUT_STEPS=['tut1','tut2','tut3','tut4','tut5','tut6'];
let tutI=0,tutActive=false;
function tutSeen(){try{return !!localStorage.getItem('matbum_tut');}catch(e){return true;}}
function tutPaint(){
 $u('tut-step').textContent=(tutI+1)+'/'+TUT_STEPS.length;
 $u('tut-text').textContent=T(TUT_STEPS[tutI]);
 $u('tut-next').textContent=tutI===TUT_STEPS.length-1?T('tut_done'):T('tut_next');
 $u('tut-skip').textContent=T('tut_skip');
}
function startTutorial(){tutI=0;tutActive=true;tutPaint();openOv('ov-tut');}
function endTutorial(){tutActive=false;closeOv('ov-tut');try{localStorage.setItem('matbum_tut','1');}catch(e){}}
$u('tut-next').onclick=()=>{S.click();if(tutI<TUT_STEPS.length-1){tutI++;tutPaint();}else endTutorial();};
$u('tut-skip').onclick=()=>{S.click();endTutorial();};
function startCol(i){
 showScreen('game');
 closeOv('ov-pause');closeOv('ov-finale');closeOv('ov-tut');tutActive=false;
 MB.start(i,opsFor(i));
 if(i===0&&!tutSeen())startTutorial();
}
MB.onFinale=st=>{
 lastFinale=st;
 const col=st.col,rec=st.score>(PROG.best[col]||0);
 if(rec)PROG.best[col]=st.score;
 const first=!PROG.unlocked[col];
 PROG.unlocked[col]=true;
 saveProg();
 lbSubmit(st.score);
 interQ=true;
 $u('fin-score').innerHTML=T('score')+': <b>'+st.score+'</b>';
 const mm=(st.time/60|0)+':'+String(st.time%60).padStart(2,'0');
 $u('fin-info').innerHTML=T('time')+': <b>'+mm+'</b> · '+T('moves')+': <b>'+st.moves+'</b>';
 $u('fin-extra').innerHTML=(first?'<p style="color:#7ef0b2">'+T('fin_unlock')+'</p>':'')
  +(rec?'<p style="color:#ffe9a3">'+T('fin_record')+'</p>':'');
 const cv=$u('finFig');cv.src=FIGIMG[col];
 $u('fin-name').textContent=T('column')+' '+(col+1)+' — '+T('fig'+col);
 openOv('ov-finale');
};
$u('fin-menu').onclick=()=>{closeOv('ov-finale');MB.stop();showScreen('select');};
$u('fin-again').onclick=()=>{closeOv('ov-finale');startCol(lastFinale.col);};
$u('fin-next').onclick=()=>{closeOv('ov-finale');startCol((lastFinale.col+1)%COLS);};

/* ------------------------------- pause ------------------------------ */
function openOv(id){const n=$u(id);if(n)n.classList.add('on');}
function closeOv(id){const n=$u(id);if(n)n.classList.remove('on');}
function openPause(){ if(curScreen!=='game')return;
 if(!MB.active()){MB.stop();showScreen('select');return;}
 MB.setActive(false);openOv('ov-pause');}
function resumeGame(){ closeOv('ov-pause');MB.setActive(true);}
$u('p-resume').onclick=resumeGame;
$u('p-exit').onclick=()=>{closeOv('ov-pause');MB.stop();showScreen('select');};
window.addEventListener('mb:pause',()=>{if(curScreen==='game')openPause();});
window.addEventListener('mb:resume',()=>{closeOv('ov-pause');if(curScreen==='game')MB.setActive(true);});
/* in-game back button -> pause */
$u('btn-back').addEventListener('click',()=>{ if(curScreen==='game'){openPause();return;} showScreen('start');});
/* confirm exit unused now (pause covers it) */

/* ------------------------------ chrome ops -------------------------- */
$u('btn-lang').addEventListener('click',()=>{setLang(lang()==='ru'?'en':'ru');paintStatic();
 if(tutActive)tutPaint();
 if(curScreen==='select')renderSelect();if(curScreen==='hall')renderHall();
 if(curScreen==='museum')renderMuseum();if(curScreen==='help')renderHelp();});
$u('btn-theme').addEventListener('click',()=>{applyTheme(theme==='dark'?'light':'dark');});
$u('btn-sound').addEventListener('click',()=>{const on=setSound(!isSoundOn());if(on)S.click();paintChrome();});

/* menu buttons */
$u('b-play').addEventListener('click',()=>{S.click();showScreen('select');});
$u('b-hall').addEventListener('click',()=>{S.click();showScreen('hall');});
$u('b-museum').addEventListener('click',()=>{S.click();showScreen('museum');});
$u('b-help').addEventListener('click',()=>{S.click();showScreen('help');});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&curScreen==='game')openPause();});
/* desktop hotkeys: arrows rotate/tilt, space auto, M sound */
document.addEventListener('keydown',e=>{
 if(curScreen!=='game'||e.repeat||e.ctrlKey||e.metaKey||e.altKey)return;
 const k=e.key;
 if(k==='ArrowLeft'){$('bL').click();e.preventDefault();}
 else if(k==='ArrowRight'){$('bR').click();e.preventDefault();}
 else if(k==='ArrowUp'){$('bU').click();e.preventDefault();}
 else if(k==='ArrowDown'){$('bD').click();e.preventDefault();}
 else if(k===' '){$('bAuto').click();e.preventDefault();}
 else if(k==='m'||k==='M'||k==='ь'||k==='Ь'){$('btn-sound').click();}
});

/* ------------------------------- boot ------------------------------- */
async function boot(){
 loadLocal();
 const pl=await initPlatform();
 let chose=false;try{chose=!!localStorage.getItem('matbum_lang');}catch(e){}
 if(!chose&&pl.lang==='en')setLang('en');
 await mergeCloud();
 paintStatic();
 showScreen('start');
 gameReady();
}
window.MB_VERSION=VERSION;
boot();
