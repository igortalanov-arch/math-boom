/* Мат-Бум sound: WebAudio synth, pause for ads */
'use strict';
let AC=null,master=null,sndOn=true;
try{sndOn=localStorage.getItem('matbum_sound')!=='off';}catch(e){}
function audio(){ if(!AC){ AC=new (window.AudioContext||window.webkitAudioContext)();
  master=AC.createGain();master.gain.value=.5;master.connect(AC.destination);
  const g=AC.createGain();g.gain.value=.015;g.connect(master);
  [55,55.6,110.3].forEach(f=>{const o=AC.createOscillator();o.frequency.value=f;o.type='sine';o.connect(g);o.start();});
 } if(AC.state==='suspended')AC.resume(); }
function tone(f,dur,type,vol,slide,delay){ if(!sndOn||!AC)return; const t=AC.currentTime+(delay||0);
  const o=AC.createOscillator(),g=AC.createGain();o.type=type||'sine';o.frequency.setValueAtTime(f,t);
  if(slide)o.frequency.exponentialRampToValueAtTime(slide,t+dur);
  g.gain.setValueAtTime(vol||.2,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);
  o.connect(g);g.connect(master);o.start(t);o.stop(t+dur+.02); }
function noise(dur,vol,hp){ if(!sndOn||!AC)return; const n=AC.sampleRate*dur|0,
  b=AC.createBuffer(1,n,AC.sampleRate),d=b.getChannelData(0);
  for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*(1-i/n);
  const s=AC.createBufferSource();s.buffer=b;const f=AC.createBiquadFilter();f.type='highpass';f.frequency.value=hp||800;
  const g=AC.createGain();g.gain.value=vol;s.connect(f);f.connect(g);g.connect(master);s.start(); }
const S={
 click:()=>tone(950,.05,'square',.08),
 sel:()=>{tone(1250,.07,'sine',.15);tone(1900,.05,'sine',.08,0,.02)},
 desel:()=>tone(700,.08,'sine',.12),
 err:()=>{tone(220,.3,'sawtooth',.12);tone(233,.3,'sawtooth',.12);noise(.15,.06,300)},
 clear:()=>{tone(1568,.12,'triangle',.22);tone(2093,.18,'triangle',.2,0,.06);noise(.06,.1,4000)},
 tick:i=>tone(700*Math.pow(1.12,i),.12,'triangle',.2),
 triple:()=>{[523,659,784,1047,1319].forEach((f,i)=>tone(f,.25,'sawtooth',.14,0,i*.07));noise(.4,.12,2000)},
 layer:()=>{[392,494,587,784].forEach(f=>tone(f,.5,'triangle',.16));},
 crack:()=>{noise(.5,.5,1500);noise(.3,.4,3000);tone(180,.4,'sawtooth',.2,60)},
 fanfare:()=>{[392,392,392,523,659,784].forEach((f,i)=>tone(f,i<3?.12:.4,'sawtooth',.16,0,i*.13));
   [1047,1319,1568].forEach((f,i)=>tone(f,.5,'triangle',.12,0,.8+i*.1));}
};
document.addEventListener('pointerdown',audio);
function setSound(on){sndOn=!!on;try{localStorage.setItem('matbum_sound',on?'on':'off');}catch(e){}
 if(master)master.gain.value=on?.5:0;return sndOn;}
function isSoundOn(){return sndOn;}
function pauseForAd(){if(master)master.gain.value=0;}
function resumeForAd(){if(master)master.gain.value=sndOn?.5:0;}
window.S=S;window.setSound=setSound;window.isSoundOn=isSoundOn;
window.pauseForAd=pauseForAd;window.resumeForAd=resumeForAd;
