/* Мат-Бум UI: screens, saves, menu/hall/museum/help, chrome toggles */
'use strict';
const VERSION='1.0.19', COLS=10, YEAR=2026;
const $u=id=>document.getElementById(id);
const OPS4=['+','−','×','÷'];
function opsFor(col){return OPS4.slice();} /* layer order fixed: + - x / */

/* ------------------------- progress & prefs ------------------------- */
let PROG={best:new Array(COLS).fill(0),bestFair:new Array(COLS).fill(0),bestAuto:new Array(COLS).fill(0),unlocked:new Array(COLS).fill(false)};
function loadLocal(){
 try{const r=JSON.parse(localStorage.getItem('matbum_v1'));
  if(r&&r.best)PROG={best:r.best.slice(0,COLS),bestFair:(r.bestFair||r.best).slice(0,COLS),bestAuto:(r.bestAuto||[]).concat(new Array(COLS).fill(0)).slice(0,COLS),unlocked:!!r.unlocked?r.unlocked.slice(0,COLS):PROG.unlocked};
 }catch(e){}
 try{const t=localStorage.getItem('matbum_theme');if(t==='light'||t==='dark')applyTheme(t,false);}catch(e){}
}
function saveProg(cloud){
 try{localStorage.setItem('matbum_v1',JSON.stringify(PROG));}catch(e){}
 if(cloud!==false)cloudSave(PROG);
}
async function mergeCloud(){
 const c=await cloudLoad();
 if(!c)return;
 for(let i=0;i<COLS;i++){
  PROG.best[i]=Math.max(PROG.best[i]||0,c.best&&c.best[i]||0);
  PROG.bestFair[i]=Math.max(PROG.bestFair[i]||0,c.bestFair&&c.bestFair[i]||0);
  PROG.bestAuto[i]=Math.max(PROG.bestAuto[i]||0,c.bestAuto&&c.bestAuto[i]||0);
  PROG.unlocked[i]=(PROG.unlocked[i]||!!(c.unlocked&&c.unlocked[i]));
 }
 try{localStorage.setItem('matbum_v1',JSON.stringify(PROG));}catch(e){}
}

/* ----------------------------- theming ------------------------------ */
let theme='dark';
function applyTheme(t,save){theme=t;document.documentElement.setAttribute('data-theme',t);
 if(save!==false){try{localStorage.setItem('matbum_theme',t);}catch(e){}}
 paintChrome();if(curScreen==='museum')renderMuseum();}

/* ------------------------------ screens ----------------------------- */
let curScreen='start',interQ=false;
function showScreen(id){
 curScreen=id;
 document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('on',s.id==='scr-'+id));
 $u('btn-back').hidden=(id==='start');
 if(id==='select')renderSelect();
 if(id==='hall')renderHall();
 if(id==='museum')renderMuseum();
 if(id==='help')renderHelp();
 if(id==='start'){renderStartSides();}
 if(id==='start'||id==='select'){ if(interQ){interQ=false;showInterstitial();} }
}
function backFrom(){
 if(curScreen==='game'){openPause();return;}
 showScreen('start');
}

/* ------------------------------ chrome ------------------------------ */
function setBtnIcon(btn,name){
 let img=btn.querySelector('img.ico');
 if(!img){img=iconImg(name,'ico');btn.insertBefore(img,btn.firstChild);}
 else img.src=ICONS[name]||'';
}
function paintChrome(){
 $u('lang-lbl').textContent=T('lang_btn');
 $u('btn-lang').title=lang()==='ru'?'English':'Русский';
 setBtnIcon($u('btn-sound'),'ui-sound');
 $u('btn-sound').classList.toggle('off',!isSoundOn());
 $u('btn-sound').title=T(isSoundOn()?'sound_on':'sound_off');
 setBtnIcon($u('btn-lang'),'ui-lang');
 setBtnIcon($u('btn-theme'),theme==='dark'?'ui-sun':'ui-moon');
 $u('btn-theme').title=T(theme==='dark'?'theme_light':'theme_dark');
 const bb=$u('btn-back');
 setBtnIcon(bb,'ui-back');
 bb.title=T('btn_back');
}
function paintStatic(){
 $u('m-logo').textContent=T('appName');
 $u('m-sub').textContent=T('appSub');
 [['b-play','btn_play','ui-play'],['b-train','btn_train','ui-train'],['b-hall','btn_hall','ui-ach'],['b-museum','btn_museum','ui-museum'],['b-help','btn_help','ui-help']]
  .forEach(a=>{const b=$u(a[0]);setBtnIcon(b,a[2]);
   let sp=b.querySelector('span.lbl');if(!sp){sp=document.createElement('span');sp.className='lbl';b.appendChild(sp);}
   sp.textContent=T(a[1]);});
 $u('m-ver').textContent=T('version_fmt',{v:VERSION});
 $u('hud-logo').innerHTML=T('appName')+'<small id="hud-sub">'+T('appSub')+' · v'+VERSION+'</small>';
 document.title=T('appName')+' '+T('appSub');
 $u('sel-title').textContent=T('choose_col');
 $u('hall-title').textContent=T('hall_title');
 $u('hall-sub').textContent=T('hall_sub');
 $u('mus-title').textContent=T('museum_title');
 $u('mus-sub').textContent=T('museum_sub');
 $u('help-title').textContent=T('help_title');
 $u('help-sub').textContent=T('help_sub');
 $u('help-footer').textContent=T('author')+' © '+YEAR+' · '+T('version_fmt',{v:VERSION});
 $u('p-title').textContent=T('pause_title');
 $u('p-keys').textContent=T('keys_help');
 $u('p-resume').textContent=T('pause_resume');
 $u('p-exit').textContent=T('pause_exit');
 $u('f-congr').textContent=T('congrats');
 $u('fin-menu').textContent=T('menu');
 $u('fin-again').textContent=T('btn_again');
 $u('fin-next').textContent=T('btn_next');
 document.querySelectorAll('#hud [data-t]').forEach(sp=>{sp.textContent=T(sp.dataset.t);});
 paintChrome();
 if(window.MB)MB.refresh();
}

/* ------------------------------ select ------------------------------ */
function renderSelect(){
 const g=$u('colgrid');g.innerHTML='';
 for(let i=0;i<COLS;i++){
  const b=document.createElement('button');b.className='colcard'+(PROG.unlocked[i]?'':' locked');b.type='button';
  b.innerHTML='<span class="num">'+(i+1)+'</span><img class="fig" alt="" src="'+FIGIMG[i]+'" onerror="figErr(this)">'
   +'<div class="nm">'+T('fig'+i)+'</div>'
   +'<div class="bst">'+(PROG.best[i]?T('best')+': '+PROG.best[i]:'—')+'</div>'
   +(PROG.unlocked[i]?'<span class="done">✔</span>':'');
  b.addEventListener('click',()=>{S.click();const t=pendingTrain||!trainSeen();pendingTrain=false;startCol(i,t);});
  g.appendChild(b);
 }
}

/* ------------------------------- hall: two rankings ------------------------------- */
function hallSec(title,sub,rows,empty){
 const d=document.createElement('div');d.className='card';
 let h='<h2>'+title+'</h2>'+(sub?'<p class="sub">'+sub+'</p>':'');
 if(!rows.length)h+='<p class="sub" style="margin-top:10px">'+empty+'</p>';
 rows.forEach((r,k)=>{h+='<div class="hallrow"><span class="rk">'+(k+1)+'</span><img width="30" height="30" style="border-radius:8px;object-fit:cover" alt="" src="'+FIGIMG[r[0]]+'" onerror="figErr(this)">'
  +'<span class="nm">'+T('column')+' '+(r[0]+1)+' · '+T('fig'+r[0])+'</span><span class="sc">'+r[1]+'</span></div>';});
 d.innerHTML=h;return d;
}
function renderHall(){
 const host=$u('hall-list');host.innerHTML='';
 const rowsF=[],rowsA=[];
 for(let i=0;i<COLS;i++){
  if(PROG.bestFair[i]>0)rowsF.push([i,PROG.bestFair[i]]);
  if(PROG.bestAuto[i]>0)rowsA.push([i,PROG.bestAuto[i]]);
 }
 rowsF.sort((x,y)=>y[1]-x[1]);rowsA.sort((x,y)=>y[1]-x[1]);
 host.appendChild(hallSec(T('hall_fair'),'',rowsF,T('hall_empty')));
 host.appendChild(hallSec(T('hall_auto'),T('hall_auto_sub'),rowsA,T('hall_empty')));
 const tot=PROG.best.reduce((x,y)=>x+y,0);
 $u('hall-total').textContent=T('hall_total')+': '+tot;
 lbTop(5,'main').then(list=>{
  const ya=$u('hall-ya');ya.innerHTML='';
  if(!list||!list.length)return;
  const h=document.createElement('div');h.className='card';h.innerHTML='<h2>Yandex Games — TOP 5 ('+T('hall_fair')+')</h2>';
  list.forEach((e,i)=>{const d=document.createElement('div');d.className='hallrow';
   d.innerHTML='<span class="rk">'+(i+1)+'</span><span class="nm">'+e.name+'</span><span class="sc">'+e.score+'</span>';
   h.appendChild(d);});
  ya.appendChild(h);
 });
}
/* ------------------------------ museum ------------------------------ */
function renderMuseum(){
 const g=$u('musgrid');g.innerHTML='';
 for(let i=0;i<COLS;i++){
  const un=PROG.unlocked[i];
  const d=document.createElement('div');d.className='muscard ped'+(un?'':' locked');
  d.innerHTML='<div class="dome'+(un?'':' lockdome')+'"><img alt="" src="'+(un?FIGIMG[i]:ICONS['ui-lock'])+'"'+(un?' onerror="figErr(this)"':'')+'></div>'
   +'<div class="base"></div>'
   +'<div class="plate">'+T('column')+' '+(i+1)+' · '+(un?T('fig'+i):'?')+'</div>'
   +(un?'':'<div class="bst sub" style="font-size:9.5px;margin-top:2px">'+T('museum_locked')+'</div>');
  d.addEventListener('click',()=>openFig(i));
  g.appendChild(d);
 }
}
function openFig(i){
 if(!PROG.unlocked[i])return; /* locked: no big card at all */
 $u('fig-big').src=FIGCARD(i);$u('fig-big').onerror=function(){figErr(this);};$u('fig-big').dataset.fb='';
 $u('fig-big').style.display='';
 $u('fig-big').style.filter='';
 $u('fig-big-name').textContent=T('column')+' '+(i+1)+' — '+T('fig'+i);
 $u('fig-big-sub').textContent=T('cleared')+' ✔';
 openOv('ov-fig');
}
$u('fig-close').onclick=()=>closeOv('ov-fig');
/* ------------------------------- help ------------------------------- */
function renderHelp(){
 const host=$u('help-body');host.innerHTML='';
 const keys=[['help_goal_t','help_goal'],['help_col_t','help_col'],['help_cubes_t','help_cubes'],
  ['help_eq_t','help_eq'],['help_tr_t','help_tr'],['help_bonus_t','help_bonus'],
  ['help_ctrl_t','help_ctrl'],['help_auto_t','help_auto'],['help_mus_t','help_mus']];
 keys.forEach(p=>{
  const c=document.createElement('div');c.className='card';
  c.innerHTML='<h2>'+T(p[0])+'</h2><p>'+T(p[1])+'</p>';
  host.appendChild(c);
 });
}

/* ---------------------------- game flow ----------------------------- */
let lastFinale=null;
/* training mode: scripted demo, then free play with any-op first layer */
let trainPhase=0,pendingTrain=false;
function trainSeen(){try{return !!localStorage.getItem('matbum_train');}catch(e){return true;}}
function setPlate(step,txt){const p=$u('trainPlate');p.hidden=false;
 $u('trStep').textContent=T('tr_step',{n:step});
 const t=$u('trText');
 if(step===2){t.innerHTML=txt.replace(/«5»/g,'<b class="t5">«5»</b>');}
 else t.textContent=txt;
 $u('hint2').style.display='none';}
window.addEventListener('mb:tsel',e=>{const n=e.detail||0;
 document.querySelectorAll('#trText .t5').forEach((el,k)=>el.classList.toggle('on',k<n));});
function hidePlate(){$u('trainPlate').hidden=true;$u('hint2').style.display='';}
function showChip(text,mode,step){const c=$u('trainChip');c.hidden=false;$u('tcText').textContent=(step?T('tr_step',{n:step})+' · ':'')+text;
 const endB=$u('tcEnd'),cont=$u('tcCont'),menu=$u('tcMenu');
 if(mode==='end'){endB.hidden=false;endB.textContent=T('tr_end');cont.hidden=true;menu.hidden=true;}
 else{endB.hidden=true;cont.hidden=false;menu.hidden=false;cont.textContent=T('tr_cont');menu.textContent=T('tr_menu');}}
function hideChip(){$u('trainChip').hidden=true;}
function startTraining(){
 trainPhase=1;hideChip();
 MB.trainAPI.phase(1);
 setPlate(1,T('train1'));
}
window.addEventListener('mb:train1',()=>{if(trainPhase!==1)return;trainPhase=2;MB.trainAPI.phase(2);setPlate(2,T('train2'));});
window.addEventListener('mb:train2',()=>{if(trainPhase!==2)return;trainPhase=4;MB.trainAPI.phase(3);hidePlate();
 try{localStorage.setItem('matbum_train','1');}catch(e){}
 showChip(T('train4'),'final');});
$u('tcCont').onclick=()=>{S.click();hideChip();MB.trainAPI.any(false);trainPhase=0;};
$u('tcMenu').onclick=()=>{S.click();hideChip();trainPhase=0;MB.trainAPI.any(false);MB.stop();showScreen('start');};
function startCol(i,train){
 showScreen('game');
 closeOv('ov-pause');closeOv('ov-finale');hideChip();hidePlate();trainPhase=0;
 const hf=$u('hud-fig');if(hf){hf.src=FIGIMG[i];hf.title=T('fig'+i);hf.alt=T('fig'+i);}
 MB.start(i,opsFor(i),{train:!!train});
 if(train&&MB.dbg().train)startTraining();
}
MB.onFinale=st=>{
 lastFinale=st;
 const col=st.col,rec=st.score>(PROG.best[col]||0);
 if(rec)PROG.best[col]=st.score;
 if(st.auto){if(st.score>(PROG.bestAuto[col]||0))PROG.bestAuto[col]=st.score;}
 else{if(st.score>(PROG.bestFair[col]||0))PROG.bestFair[col]=st.score;}
 const first=!PROG.unlocked[col];
 PROG.unlocked[col]=true;
 saveProg();
 lbSubmit(st.score,st.auto?'auto':'main');
 interQ=true;
 $u('fin-score').innerHTML=T('score')+': <b>'+st.score+'</b>';
 const mm=(st.time/60|0)+':'+String(st.time%60).padStart(2,'0');
 $u('fin-info').innerHTML=T('time')+': <b>'+mm+'</b> · '+T('moves')+': <b>'+st.moves+'</b>';
 $u('fin-extra').innerHTML=(first?'<p style="color:#7ef0b2">'+T('fin_unlock')+'</p>':'')
  +(rec?'<p style="color:#ffe9a3">'+T('fin_record')+'</p>':'');
 const cv=$u('finFig');cv.src=FIGHERO(col);cv.onerror=function(){figErr(this);};
 $u('fin-name').textContent=T('column')+' '+(col+1)+' — '+T('fig'+col);
 openOv('ov-finale');
};
$u('fin-menu').onclick=()=>{closeOv('ov-finale');MB.stop();showScreen('start');};
$u('fin-again').onclick=()=>{closeOv('ov-finale');startCol(lastFinale.col);};
$u('fin-next').onclick=()=>{closeOv('ov-finale');startCol((lastFinale.col+1)%COLS);};

/* ------------------------------- pause ------------------------------ */
function openOv(id){const n=$u(id);if(n)n.classList.add('on');}
function closeOv(id){const n=$u(id);if(n)n.classList.remove('on');}
function openPause(){ if(curScreen!=='game')return;
 if(!MB.active()){MB.stop();showScreen('select');return;}
 MB.setActive(false);openOv('ov-pause');}
function resumeGame(){ closeOv('ov-pause');MB.setActive(true);}
$u('p-resume').onclick=resumeGame;
$u('p-exit').onclick=()=>{closeOv('ov-pause');MB.stop();showScreen('start');};
window.addEventListener('mb:pause',()=>{if(curScreen==='game')openPause();});
window.addEventListener('mb:resume',()=>{closeOv('ov-pause');if(curScreen==='game')MB.setActive(true);});
/* in-game back button -> pause */
$u('btn-back').addEventListener('click',()=>{ if(curScreen==='game'){openPause();return;} showScreen('start');});
/* confirm exit unused now (pause covers it) */

/* ------------------------------ chrome ops -------------------------- */
$u('btn-lang').addEventListener('click',()=>{setLang(lang()==='ru'?'en':'ru');paintStatic();
 if(curScreen==='start')renderStartSides();
 if(curScreen==='select')renderSelect();if(curScreen==='hall')renderHall();
 if(curScreen==='museum')renderMuseum();if(curScreen==='help')renderHelp();
 if(trainPhase===1)setPlate(1,T('train1'));else if(trainPhase===2)setPlate(2,T('train2'));});
window.addEventListener('mb:terr',()=>{const t=$u('trText');if(!t)return;
 t.classList.add('terr');t.textContent=T('tr_order_err');});
window.addEventListener('mb:tok',()=>{const t=$u('trText');if(!t||!t.classList.contains('terr'))return;
 t.classList.remove('terr');
 if(trainPhase===1)setPlate(1,T('train1'));else if(trainPhase===2)setPlate(2,T('train2'));});
$u('btn-theme').addEventListener('click',()=>{applyTheme(theme==='dark'?'light':'dark');});
$u('btn-sound').addEventListener('click',()=>{const on=setSound(!isSoundOn());if(on)S.click();paintChrome();});

/* menu buttons */
$u('b-play').addEventListener('click',()=>{S.click();showScreen('select');});
$u('b-hall').addEventListener('click',()=>{S.click();showScreen('hall');});
$u('b-museum').addEventListener('click',()=>{S.click();showScreen('museum');});
$u('b-help').addEventListener('click',()=>{S.click();showScreen('help');});
$u('b-train').addEventListener('click',()=>{S.click();pendingTrain=true;showScreen('select');});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&curScreen==='game')openPause();});
/* desktop hotkeys: arrows rotate/tilt, space auto, M sound */
document.addEventListener('keydown',e=>{
 if(curScreen!=='game'||e.repeat||e.ctrlKey||e.metaKey||e.altKey)return;
 const k=e.key;
 if(k==='ArrowLeft'){$('bL').click();e.preventDefault();}
 else if(k==='ArrowRight'){$('bR').click();e.preventDefault();}
 else if(k==='ArrowUp'){$('bU').click();e.preventDefault();}
 else if(k==='ArrowDown'){$('bD').click();e.preventDefault();}
 else if(k===' '){$('bAuto').click();e.preventDefault();}
 else if(k==='m'||k==='M'||k==='ь'||k==='Ь'){$('btn-sound').click();}
});

/* --------------------- desktop form + start sides --------------------- */
function detectForm(){const d=window.matchMedia&&matchMedia('(pointer: fine)').matches&&innerWidth>=1024;
 document.body.classList.toggle('desktop',!!d);document.body.classList.toggle('mobile',!d);}
addEventListener('resize',detectForm);
function renderStartSides(){
 const L=$u('side-l'),R=$u('side-r');if(!L||!R)return;
 let open=0;for(let i=0;i<COLS;i++)if(PROG.unlocked[i])open++;
 let h='<h3>'+T('museum_title')+'</h3><div class="minigrid" id="minigrid"></div><div class="sub">'+T('side_open',{a:open,b:COLS})+'</div>';
 L.innerHTML=h;
 const g=$u('minigrid');
 for(let i=0;i<COLS;i++){
  const un=PROG.unlocked[i];
  const im=document.createElement('img');im.alt='';im.title=T('fig'+i);
  im.src=un?FIGIMG[i]:ICONS['ui-lock'];
  if(un)im.onerror=function(){figErr(this);};
  if(un){im.className='un';im.addEventListener('click',()=>openFig(i));}
  else im.className='lk';
  g.appendChild(im);}
 const rows=[];for(let i=0;i<COLS;i++)if(PROG.best[i]>0)rows.push([i,PROG.best[i]]);
 rows.sort((a,b)=>b[1]-a[1]);
 let r='<h3>'+T('side_top')+'</h3>';
 if(!rows.length)r+='<div class="sub">'+T('hall_empty')+'</div>';
 rows.slice(0,3).forEach((e,k)=>{r+='<div class="srow"><span class="rk">'+(k+1)+'</span><span>'+T('column')+' '+(e[0]+1)+' · '+T('fig'+e[0])+'</span><span class="sc">'+e[1]+'</span></div>';});
 const tot=PROG.best.reduce((a,b)=>a+b,0);
 r+='<div class="srow" style="margin-top:8px"><span>'+T('side_total')+'</span><span class="sc">'+tot+'</span></div>';
 r+='<div id="side-ya"></div>';
 R.innerHTML=r;
 lbTop(3,'main').then(list=>{const ya=$u('side-ya');if(!ya)return;ya.innerHTML='';
  if(!list||!list.length)return;
  let y='<h3 style="margin-top:10px">'+T('side_ya')+'</h3>';
  list.forEach((e,i)=>{y+='<div class="srow"><span class="rk">'+(i+1)+'</span><span>'+e.name+'</span><span class="sc">'+e.score+'</span></div>';});
  ya.innerHTML=y;});
}
/* ------------------------------- boot ------------------------------- */
async function boot(){
 detectForm();
 loadLocal();
 const pl=await initPlatform();
 let chose=false;try{chose=!!localStorage.getItem('matbum_lang');}catch(e){}
 if(!chose&&pl.lang==='en')setLang('en');
 await mergeCloud();
 paintStatic();
 showScreen('start');
 gameReady();
}
window.MB_VERSION=VERSION;
boot();
